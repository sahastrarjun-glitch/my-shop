package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Shop::class,
        User::class,
        MobileItem::class,
        MobileMovement::class,
        SaleRecord::class,
        RepairRecord::class,
        ReturnRecord::class,
        ExchangeRecord::class,
        DueRecord::class,
        DuePayment::class,
        CashBankTransaction::class,
        DailyEntry::class,
        ExpenseRecord::class,
        StaffEntity::class,
        StaffAdvance::class,
        StaffLeave::class,
        AuditLog::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun shopDao(): ShopDao
    abstract fun mobileDao(): MobileDao
    abstract fun transactionDao(): TransactionDao
    abstract fun dueDao(): DueDao
    abstract fun staffDao(): StaffDao
    abstract fun auditDao(): AuditDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "my_shop_database"
                )
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        seedInitialData(database)
                    }
                }
            }
        }

        private suspend fun seedInitialData(database: AppDatabase) {
            val shopDao = database.shopDao()
            val transactionDao = database.transactionDao()

            // Seed Shops
            val shop1 = Shop(
                id = "shop_1",
                name = "Shop 1 - Main Branch",
                address = "Main Market, Station Road",
                phone = "9876543210",
                openingCash = 25000.0,
                openingBank = 50000.0
            )
            val shop2 = Shop(
                id = "shop_2",
                name = "Shop 2 - City Market",
                address = "City Plaza, Shop #14",
                phone = "9876543211",
                openingCash = 15000.0,
                openingBank = 35000.0
            )
            shopDao.insertShop(shop1)
            shopDao.insertShop(shop2)

            // Seed 3 Authorized Users
            val user1 = User(
                id = "user_owner",
                name = "Owner / Super Admin",
                pin = "1234",
                role = "ADMIN",
                assignedShopId = null
            )
            val user2 = User(
                id = "user_mgr1",
                name = "Shop 1 Manager",
                pin = "1111",
                role = "MANAGER",
                assignedShopId = "shop_1"
            )
            val user3 = User(
                id = "user_mgr2",
                name = "Shop 2 Manager",
                pin = "2222",
                role = "MANAGER",
                assignedShopId = "shop_2"
            )
            shopDao.insertUser(user1)
            shopDao.insertUser(user2)
            shopDao.insertUser(user3)

            // Seed initial opening balance transactions
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = "shop_1",
                    type = "CASH_IN",
                    amount = 25000.0,
                    category = "Opening Balance",
                    userId = "user_owner",
                    userName = "Owner / Super Admin",
                    notes = "Initial cash balance"
                )
            )
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = "shop_1",
                    type = "BANK_IN",
                    amount = 50000.0,
                    category = "Opening Balance",
                    userId = "user_owner",
                    userName = "Owner / Super Admin",
                    notes = "Initial bank balance"
                )
            )
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = "shop_2",
                    type = "CASH_IN",
                    amount = 15000.0,
                    category = "Opening Balance",
                    userId = "user_owner",
                    userName = "Owner / Super Admin",
                    notes = "Initial cash balance"
                )
            )
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = "shop_2",
                    type = "BANK_IN",
                    amount = 35000.0,
                    category = "Opening Balance",
                    userId = "user_owner",
                    userName = "Owner / Super Admin",
                    notes = "Initial bank balance"
                )
            )
        }
    }
}

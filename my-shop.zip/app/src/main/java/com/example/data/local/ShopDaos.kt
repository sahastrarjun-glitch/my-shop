package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ShopDao {
    @Query("SELECT * FROM shops")
    fun getAllShops(): Flow<List<Shop>>

    @Query("SELECT * FROM shops WHERE id = :shopId")
    suspend fun getShopById(shopId: String): Shop?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShop(shop: Shop)

    @Query("SELECT * FROM users")
    fun getAllUsers(): Flow<List<User>>

    @Query("SELECT * FROM users WHERE id = :userId")
    suspend fun getUserById(userId: String): User?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Query("UPDATE shops SET openingCash = :cash, openingBank = :bank WHERE id = :shopId")
    suspend fun updateOpeningBalances(shopId: String, cash: Double, bank: Double)
}

@Dao
interface MobileDao {
    @Query("SELECT * FROM mobiles WHERE shopId = :shopId AND status IN ('IN_STOCK', 'REPAIRING') ORDER BY purchaseDate DESC")
    fun getCurrentStock(shopId: String): Flow<List<MobileItem>>

    @Query("SELECT * FROM mobiles WHERE shopId = :shopId ORDER BY purchaseDate DESC")
    fun getAllMobilesForShop(shopId: String): Flow<List<MobileItem>>

    @Query("SELECT * FROM mobiles WHERE id = :id")
    suspend fun getMobileById(id: Long): MobileItem?

    @Query("SELECT * FROM mobiles WHERE imei1 = :imei OR imei2 = :imei LIMIT 1")
    suspend fun findByImei(imei: String): MobileItem?

    @Query("SELECT * FROM mobiles WHERE (imei1 = :imei OR (imei2 != '' AND imei2 = :imei)) AND id != :excludeId LIMIT 1")
    suspend fun checkDuplicateImei(imei: String, excludeId: Long = 0): MobileItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMobile(mobile: MobileItem): Long

    @Update
    suspend fun updateMobile(mobile: MobileItem)

    // Movements
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMovement(movement: MobileMovement): Long

    @Query("SELECT * FROM mobile_movements WHERE shopId = :shopId ORDER BY timestamp DESC")
    fun getMovementsForShop(shopId: String): Flow<List<MobileMovement>>

    @Query("SELECT * FROM mobile_movements WHERE imei = :imei ORDER BY timestamp ASC")
    fun getTimelineForImei(imei: String): Flow<List<MobileMovement>>

    @Query("SELECT * FROM mobile_movements WHERE shopId = :shopId AND direction = :direction ORDER BY timestamp DESC")
    fun getMovementsByDirection(shopId: String, direction: String): Flow<List<MobileMovement>>
}

@Dao
interface TransactionDao {
    // Sales
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSale(sale: SaleRecord): Long

    @Query("SELECT * FROM sales WHERE shopId = :shopId ORDER BY timestamp DESC")
    fun getSalesForShop(shopId: String): Flow<List<SaleRecord>>

    @Query("SELECT * FROM sales WHERE id = :id")
    suspend fun getSaleById(id: Long): SaleRecord?

    @Update
    suspend fun updateSale(sale: SaleRecord)

    // Repairs
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepair(repair: RepairRecord): Long

    @Query("SELECT * FROM repairs WHERE shopId = :shopId ORDER BY timestamp DESC")
    fun getRepairsForShop(shopId: String): Flow<List<RepairRecord>>

    @Query("SELECT * FROM repairs WHERE imei = :imei ORDER BY timestamp DESC")
    fun getRepairsForImei(imei: String): Flow<List<RepairRecord>>

    @Update
    suspend fun updateRepair(repair: RepairRecord)

    // Returns
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReturn(returnRecord: ReturnRecord): Long

    @Query("SELECT * FROM returns WHERE shopId = :shopId ORDER BY timestamp DESC")
    fun getReturnsForShop(shopId: String): Flow<List<ReturnRecord>>

    // Exchanges
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExchange(exchangeRecord: ExchangeRecord): Long

    @Query("SELECT * FROM exchanges WHERE shopId = :shopId ORDER BY timestamp DESC")
    fun getExchangesForShop(shopId: String): Flow<List<ExchangeRecord>>

    // Daily Entries
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyEntry(entry: DailyEntry): Long

    @Query("SELECT * FROM daily_entries WHERE shopId = :shopId ORDER BY timestamp DESC")
    fun getDailyEntriesForShop(shopId: String): Flow<List<DailyEntry>>

    @Update
    suspend fun updateDailyEntry(entry: DailyEntry)

    // Cash / Bank Transactions
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCashBankTransaction(tx: CashBankTransaction): Long

    @Query("SELECT * FROM cash_bank_transactions WHERE shopId = :shopId ORDER BY timestamp DESC")
    fun getCashBankTransactions(shopId: String): Flow<List<CashBankTransaction>>

    // Expenses
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseRecord): Long

    @Query("SELECT * FROM expenses WHERE shopId = :shopId ORDER BY timestamp DESC")
    fun getExpensesForShop(shopId: String): Flow<List<ExpenseRecord>>
}

@Dao
interface DueDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDue(due: DueRecord): Long

    @Update
    suspend fun updateDue(due: DueRecord)

    @Query("SELECT * FROM dues WHERE id = :id")
    suspend fun getDueById(id: Long): DueRecord?

    @Query("SELECT * FROM dues WHERE shopId = :shopId ORDER BY createdAt DESC")
    fun getAllDuesForShop(shopId: String): Flow<List<DueRecord>>

    @Query("SELECT * FROM dues WHERE shopId = :shopId AND dueDirection = :direction ORDER BY createdAt DESC")
    fun getDuesByDirection(shopId: String, direction: String): Flow<List<DueRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDuePayment(payment: DuePayment): Long

    @Query("SELECT * FROM due_payments WHERE dueId = :dueId ORDER BY timestamp DESC")
    fun getPaymentsForDue(dueId: Long): Flow<List<DuePayment>>
}

@Dao
interface StaffDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStaff(staff: StaffEntity): Long

    @Query("SELECT * FROM staff WHERE shopId = :shopId ORDER BY name ASC")
    fun getStaffForShop(shopId: String): Flow<List<StaffEntity>>

    @Query("SELECT * FROM staff WHERE id = :id")
    suspend fun getStaffById(id: Long): StaffEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdvance(advance: StaffAdvance): Long

    @Query("SELECT * FROM staff_advances WHERE shopId = :shopId ORDER BY timestamp DESC")
    fun getAdvancesForShop(shopId: String): Flow<List<StaffAdvance>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeave(leave: StaffLeave): Long

    @Query("SELECT * FROM staff_leaves WHERE shopId = :shopId ORDER BY timestamp DESC")
    fun getLeavesForShop(shopId: String): Flow<List<StaffLeave>>
}

@Dao
interface AuditDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLog): Long

    @Query("SELECT * FROM audit_logs WHERE shopId = :shopId ORDER BY timestamp DESC LIMIT 100")
    fun getLogsForShop(shopId: String): Flow<List<AuditLog>>
}

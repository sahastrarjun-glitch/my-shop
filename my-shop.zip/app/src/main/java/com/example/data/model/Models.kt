package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents the two shops managed in the app.
 */
@Entity(tableName = "shops")
data class Shop(
    @PrimaryKey val id: String, // "shop_1", "shop_2"
    val name: String,
    val address: String,
    val phone: String,
    val openingCash: Double = 0.0,
    val openingBank: Double = 0.0
)

/**
 * Exactly 3 authorized users for secure login and role-based permissions.
 */
@Entity(tableName = "users")
data class User(
    @PrimaryKey val id: String, // "user_owner", "user_mgr1", "user_mgr2"
    val name: String,
    val pin: String,
    val role: String, // "ADMIN" or "MANAGER"
    val assignedShopId: String? = null // null means both shops (Admin)
)

/**
 * Mobile inventory tracked by unique IMEI.
 */
@Entity(tableName = "mobiles")
data class MobileItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val imei1: String,
    val imei2: String = "",
    val brand: String,
    val model: String,
    val ram: String = "",
    val storage: String = "",
    val color: String = "",
    val condition: String = "Good", // "Like New", "Good", "Fair", "Needs Repair"
    val purchasePrice: Double = 0.0,
    val totalRepairCost: Double = 0.0,
    val totalCost: Double = 0.0, // purchasePrice + totalRepairCost
    val status: String = "IN_STOCK", // "IN_STOCK", "REPAIRING", "SOLD", "RETURNED", "EXCHANGED"
    val purchaseDate: Long = System.currentTimeMillis(),
    val sellerName: String = "",
    val sellerMobile: String = "",
    val sellerAadhaarMasked: String = "", // e.g. "XXXX-XXXX-1234"
    val sellerAddress: String = "",
    val notes: String = "",
    val shopId: String,
    val createdAt: Long = System.currentTimeMillis(),
    val createdBy: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Permanent lifetime IN/OUT movement registers.
 */
@Entity(tableName = "mobile_movements")
data class MobileMovement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shopId: String,
    val imei: String,
    val brandModel: String,
    val direction: String, // "IN" or "OUT"
    val reason: String, // "Purchase", "Sale", "Customer Return", "Return to Seller", "Exchange In", "Exchange Out"
    val personName: String,
    val personMobile: String = "",
    val value: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val userId: String,
    val userName: String,
    val notes: String = ""
)

/**
 * Sale record storing exact sale price, costs, and profit/loss.
 */
@Entity(tableName = "sales")
data class SaleRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shopId: String,
    val mobileId: Long,
    val imei: String,
    val brandModel: String,
    val customerName: String,
    val customerMobile: String,
    val customerAddress: String = "",
    val purchasePrice: Double,
    val repairCost: Double,
    val totalCost: Double,
    val salePrice: Double,
    val profitOrLoss: Double, // salePrice - totalCost
    val cashPaid: Double,
    val bankPaid: Double,
    val dueAmount: Double,
    val paymentRef: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val userId: String,
    val userName: String,
    val isReversed: Boolean = false,
    val reversedAt: Long? = null,
    val reversedBy: String? = null
)

/**
 * Repair entries linked to specific IMEI.
 */
@Entity(tableName = "repairs")
data class RepairRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shopId: String,
    val mobileId: Long,
    val imei: String,
    val brandModel: String,
    val repairDetails: String,
    val technicianOrVendor: String,
    val cost: Double,
    val cashPaid: Double,
    val bankPaid: Double,
    val dueAmount: Double,
    val paymentRef: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val userId: String,
    val userName: String,
    val isCompleted: Boolean = true,
    val notes: String = ""
)

/**
 * Return record for Customer Returns or Shop returning mobile to Seller.
 */
@Entity(tableName = "returns")
data class ReturnRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shopId: String,
    val returnType: String, // "CUSTOMER_RETURN" or "SHOP_TO_SELLER"
    val imei: String,
    val brandModel: String,
    val personName: String,
    val personMobile: String,
    val reason: String,
    val refundAmount: Double,
    val cashAmount: Double,
    val bankAmount: Double,
    val dueAmount: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val userId: String,
    val userName: String,
    val notes: String = ""
)

/**
 * Mobile-for-mobile exchange record.
 */
@Entity(tableName = "exchanges")
data class ExchangeRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shopId: String,
    val customerName: String,
    val customerMobile: String,
    val incomingImei: String,
    val incomingBrandModel: String,
    val incomingValue: Double,
    val outgoingImei: String,
    val outgoingBrandModel: String,
    val outgoingValue: Double,
    val differenceAmount: Double, // outgoingValue - incomingValue
    val customerPaidCash: Double = 0.0,
    val customerPaidBank: Double = 0.0,
    val shopPaidCash: Double = 0.0,
    val shopPaidBank: Double = 0.0,
    val dueAmount: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis(),
    val userId: String,
    val userName: String,
    val notes: String = ""
)

/**
 * Two-way Due System:
 * LENA_HAI = Receivable (Customer owes shop)
 * DENA_HAI = Payable (Shop owes seller or technician)
 */
@Entity(tableName = "dues")
data class DueRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shopId: String,
    val dueDirection: String, // "LENA_HAI" or "DENA_HAI"
    val personName: String,
    val personMobile: String,
    val personRole: String = "CUSTOMER", // "CUSTOMER", "SELLER", "VENDOR"
    val relatedImei: String = "",
    val relatedTransactionType: String = "", // "SALE", "PURCHASE", "REPAIR", "EXCHANGE", "MANUAL"
    val originalAmount: Double,
    val paidAmount: Double = 0.0,
    val remainingAmount: Double,
    val dueDate: Long = System.currentTimeMillis() + (7L * 24 * 60 * 60 * 1000), // default 7 days
    val createdAt: Long = System.currentTimeMillis(),
    val clearedAt: Long? = null,
    val durationDays: Int? = null,
    val status: String = "ACTIVE", // "ACTIVE", "PARTIAL", "CLEARED", "OVERDUE"
    val userId: String,
    val userName: String,
    val notes: String = ""
)

/**
 * Partial or full due payment history.
 */
@Entity(tableName = "due_payments")
data class DuePayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dueId: Long,
    val shopId: String,
    val amount: Double,
    val cashAmount: Double,
    val bankAmount: Double,
    val paymentRef: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val userId: String,
    val userName: String,
    val remainingAfterPayment: Double,
    val notes: String = ""
)

/**
 * Cash & Bank transactions ledger.
 */
@Entity(tableName = "cash_bank_transactions")
data class CashBankTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shopId: String,
    val type: String, // "CASH_IN", "CASH_OUT", "BANK_IN", "BANK_OUT", "TRANSFER_CASH_TO_BANK", "TRANSFER_BANK_TO_CASH"
    val amount: Double,
    val category: String, // "Purchase", "Sale", "Repair", "Return", "Exchange", "Expense", "Staff Advance", "Due Payment", "Transfer", "Opening Balance"
    val referenceImei: String = "",
    val referencePerson: String = "",
    val bankOrUpiDetails: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val userId: String,
    val userName: String,
    val notes: String = ""
)

/**
 * Unified Daily Entry Journal.
 */
@Entity(tableName = "daily_entries")
data class DailyEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shopId: String,
    val entryType: String, // "Purchase", "Sale", "Repair", "Return", "Exchange", "Expense", "Food", "Staff Advance", "Due Created", "Due Payment", "Staff Leave", "Cash/Bank Transfer", "Other"
    val amount: Double,
    val description: String,
    val paymentMode: String = "Cash", // "Cash", "Bank/Online", "Cash + Bank", "Due", "None"
    val cashPart: Double = 0.0,
    val bankPart: Double = 0.0,
    val duePart: Double = 0.0,
    val person: String = "",
    val imei: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val userId: String,
    val userName: String,
    val isReversed: Boolean = false
)

/**
 * Expenses and Food records.
 */
@Entity(tableName = "expenses")
data class ExpenseRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shopId: String,
    val category: String, // "Shop Expense", "Electricity", "Transport", "Food", "Repair-related", "Salary", "Rent", "Other"
    val amount: Double,
    val paymentMode: String = "Cash", // "Cash", "Bank/Online"
    val description: String,
    val staffOrPerson: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val userId: String,
    val userName: String
)

/**
 * Staff profiles.
 */
@Entity(tableName = "staff")
data class StaffEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shopId: String,
    val name: String,
    val mobile: String,
    val salary: Double,
    val joiningDate: Long = System.currentTimeMillis(),
    val notes: String = ""
)

/**
 * Staff Advance tracking.
 */
@Entity(tableName = "staff_advances")
data class StaffAdvance(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val staffId: Long,
    val staffName: String,
    val shopId: String,
    val amount: Double,
    val remainingAdvance: Double,
    val paymentMode: String = "Cash",
    val purpose: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val userId: String,
    val userName: String
)

/**
 * Staff Leave records.
 */
@Entity(tableName = "staff_leaves")
data class StaffLeave(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val staffId: Long,
    val staffName: String,
    val shopId: String,
    val startDate: Long = System.currentTimeMillis(),
    val days: Int = 1,
    val reason: String = "",
    val isPaid: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val userId: String,
    val userName: String
)

/**
 * Security and Audit logs.
 */
@Entity(tableName = "audit_logs")
data class AuditLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shopId: String,
    val action: String, // "CREATE", "UPDATE", "REVERSE", "LOGIN", "TRANSFER"
    val entityType: String, // "PURCHASE", "SALE", "REPAIR", "DUE", "EXPENSE", "TRANSFER"
    val entityId: String,
    val details: String,
    val userId: String,
    val userName: String,
    val timestamp: Long = System.currentTimeMillis()
)

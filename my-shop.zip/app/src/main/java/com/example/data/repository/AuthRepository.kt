package com.example.data.repository

import com.example.data.model.Shop
import com.example.data.model.User
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AuthRepository(private val shopRepository: ShopRepository) {

    // Default to Owner / Super Admin
    private val defaultUser = User(
        id = "user_owner",
        name = "Owner / Super Admin",
        pin = "1234",
        role = "ADMIN",
        assignedShopId = null
    )

    private val _currentUser = MutableStateFlow<User>(defaultUser)
    val currentUser: StateFlow<User> = _currentUser.asStateFlow()

    private val _selectedShopId = MutableStateFlow("shop_1")
    val selectedShopId: StateFlow<String> = _selectedShopId.asStateFlow()

    private val _isAuthenticated = MutableStateFlow(true)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    fun selectShop(shopId: String) {
        val user = _currentUser.value
        if (user.role == "ADMIN" || user.assignedShopId == null || user.assignedShopId == shopId) {
            _selectedShopId.value = shopId
        }
    }

    suspend fun loginWithPin(userId: String, pin: String): Boolean {
        val user = shopRepository.verifyPin(userId, pin)
        return if (user != null) {
            _currentUser.value = user
            _isAuthenticated.value = true
            // If user is assigned to a specific shop, automatically select that shop
            user.assignedShopId?.let { assignedShop ->
                _selectedShopId.value = assignedShop
            }
            true
        } else {
            false
        }
    }

    fun logout() {
        _isAuthenticated.value = false
    }

    fun switchUserDirectly(user: User) {
        _currentUser.value = user
        _isAuthenticated.value = true
        user.assignedShopId?.let { assignedShop ->
            _selectedShopId.value = assignedShop
        }
    }
}

package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class ShopRepository(private val db: AppDatabase) {

    // DAOs
    val shopDao = db.shopDao()
    val mobileDao = db.mobileDao()
    val transactionDao = db.transactionDao()
    val dueDao = db.dueDao()
    val staffDao = db.staffDao()
    val auditDao = db.auditDao()

    // Shops & Users
    fun getShops(): Flow<List<Shop>> = shopDao.getAllShops()
    fun getUsers(): Flow<List<User>> = shopDao.getAllUsers()

    suspend fun verifyPin(userId: String, pin: String): User? {
        val user = shopDao.getUserById(userId)
        return if (user != null && user.pin == pin) user else null
    }

    suspend fun updateOpeningBalances(shopId: String, cash: Double, bank: Double, user: User) {
        shopDao.updateOpeningBalances(shopId, cash, bank)
        auditDao.insertLog(
            AuditLog(
                shopId = shopId,
                action = "UPDATE",
                entityType = "OPENING_BALANCE",
                entityId = shopId,
                details = "Updated opening balances: Cash=₹$cash, Bank=₹$bank",
                userId = user.id,
                userName = user.name
            )
        )
    }

    // Mobile Stock & Details
    fun getCurrentStock(shopId: String): Flow<List<MobileItem>> = mobileDao.getCurrentStock(shopId)
    fun getAllMobiles(shopId: String): Flow<List<MobileItem>> = mobileDao.getAllMobilesForShop(shopId)
    suspend fun getMobileById(id: Long): MobileItem? = mobileDao.getMobileById(id)
    suspend fun findByImei(imei: String): MobileItem? = mobileDao.findByImei(imei)
    suspend fun checkDuplicateImei(imei: String, excludeId: Long = 0): Boolean {
        return mobileDao.checkDuplicateImei(imei, excludeId) != null
    }

    fun getMovementsForShop(shopId: String): Flow<List<MobileMovement>> = mobileDao.getMovementsForShop(shopId)
    fun getMovementsByDirection(shopId: String, direction: String): Flow<List<MobileMovement>> =
        mobileDao.getMovementsByDirection(shopId, direction)
    fun getTimelineForImei(imei: String): Flow<List<MobileMovement>> = mobileDao.getTimelineForImei(imei)
    fun getRepairsForImei(imei: String): Flow<List<RepairRecord>> = transactionDao.getRepairsForImei(imei)

    // Daily Entries & Financials
    fun getDailyEntries(shopId: String): Flow<List<DailyEntry>> = transactionDao.getDailyEntriesForShop(shopId)
    fun getCashBankTransactions(shopId: String): Flow<List<CashBankTransaction>> =
        transactionDao.getCashBankTransactions(shopId)
    fun getSales(shopId: String): Flow<List<SaleRecord>> = transactionDao.getSalesForShop(shopId)
    fun getRepairs(shopId: String): Flow<List<RepairRecord>> = transactionDao.getRepairsForShop(shopId)
    fun getReturns(shopId: String): Flow<List<ReturnRecord>> = transactionDao.getReturnsForShop(shopId)
    fun getExchanges(shopId: String): Flow<List<ExchangeRecord>> = transactionDao.getExchangesForShop(shopId)
    fun getExpenses(shopId: String): Flow<List<ExpenseRecord>> = transactionDao.getExpensesForShop(shopId)

    // Dues
    fun getAllDues(shopId: String): Flow<List<DueRecord>> = dueDao.getAllDuesForShop(shopId)
    fun getDuesByDirection(shopId: String, direction: String): Flow<List<DueRecord>> =
        dueDao.getDuesByDirection(shopId, direction)
    fun getDuePayments(dueId: Long): Flow<List<DuePayment>> = dueDao.getPaymentsForDue(dueId)

    // Staff
    fun getStaff(shopId: String): Flow<List<StaffEntity>> = staffDao.getStaffForShop(shopId)
    fun getStaffAdvances(shopId: String): Flow<List<StaffAdvance>> = staffDao.getAdvancesForShop(shopId)
    fun getStaffLeaves(shopId: String): Flow<List<StaffLeave>> = staffDao.getLeavesForShop(shopId)
    suspend fun addStaff(staff: StaffEntity) = staffDao.insertStaff(staff)

    // Audits
    fun getAuditLogs(shopId: String): Flow<List<AuditLog>> = auditDao.getLogsForShop(shopId)

    // ==========================================
    // CORE AUTOMATIC RECONCILIATION TRANSACTIONS
    // ==========================================

    /**
     * 1. PURCHASE: ENTER ONCE -> AUTOMATICALLY UPDATE EVERYTHING
     * Adds mobile to Stock, creates Mobile IN, updates Cash/Bank/Due, adds Daily Entry, creates audit log.
     */
    suspend fun recordPurchase(
        shopId: String,
        imei1: String,
        imei2: String = "",
        brand: String,
        model: String,
        ram: String,
        storage: String,
        color: String,
        condition: String,
        purchasePrice: Double,
        sellerName: String,
        sellerMobile: String,
        sellerAadhaar: String,
        sellerAddress: String,
        notes: String,
        cashPaid: Double,
        bankPaid: Double,
        dueAmount: Double,
        paymentRef: String,
        user: User
    ): Long {
        val now = System.currentTimeMillis()
        val maskedAadhaar = if (sellerAadhaar.length >= 4) {
            "XXXX-XXXX-${sellerAadhaar.takeLast(4)}"
        } else sellerAadhaar

        // 1. Insert into Mobile Stock
        val mobile = MobileItem(
            imei1 = imei1.trim(),
            imei2 = imei2.trim(),
            brand = brand.trim(),
            model = model.trim(),
            ram = ram.trim(),
            storage = storage.trim(),
            color = color.trim(),
            condition = condition,
            purchasePrice = purchasePrice,
            totalRepairCost = 0.0,
            totalCost = purchasePrice,
            status = "IN_STOCK",
            purchaseDate = now,
            sellerName = sellerName.trim(),
            sellerMobile = sellerMobile.trim(),
            sellerAadhaarMasked = maskedAadhaar,
            sellerAddress = sellerAddress.trim(),
            notes = notes.trim(),
            shopId = shopId,
            createdAt = now,
            createdBy = user.name,
            updatedAt = now
        )
        val mobileId = mobileDao.insertMobile(mobile)

        // 2. Insert Mobile IN Register
        mobileDao.insertMovement(
            MobileMovement(
                shopId = shopId,
                imei = imei1.trim(),
                brandModel = "$brand $model",
                direction = "IN",
                reason = "Purchase",
                personName = sellerName.trim(),
                personMobile = sellerMobile.trim(),
                value = purchasePrice,
                timestamp = now,
                userId = user.id,
                userName = user.name,
                notes = "Purchased from seller"
            )
        )

        // 3. Update Cash & Bank Ledgers
        if (cashPaid > 0) {
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = shopId,
                    type = "CASH_OUT",
                    amount = cashPaid,
                    category = "Purchase",
                    referenceImei = imei1.trim(),
                    referencePerson = sellerName.trim(),
                    timestamp = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Cash payment for $brand $model"
                )
            )
        }
        if (bankPaid > 0) {
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = shopId,
                    type = "BANK_OUT",
                    amount = bankPaid,
                    category = "Purchase",
                    referenceImei = imei1.trim(),
                    referencePerson = sellerName.trim(),
                    bankOrUpiDetails = paymentRef.trim(),
                    timestamp = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Bank/Online payment for $brand $model"
                )
            )
        }

        // 4. Update Due (DENA HAI - Money shop has to pay to seller)
        if (dueAmount > 0) {
            dueDao.insertDue(
                DueRecord(
                    shopId = shopId,
                    dueDirection = "DENA_HAI",
                    personName = sellerName.trim(),
                    personMobile = sellerMobile.trim(),
                    personRole = "SELLER",
                    relatedImei = imei1.trim(),
                    relatedTransactionType = "PURCHASE",
                    originalAmount = dueAmount,
                    remainingAmount = dueAmount,
                    createdAt = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Purchase payable for $brand $model"
                )
            )
        }

        // 5. Add to Daily Entry Journal
        val paymentMode = determinePaymentMode(cashPaid, bankPaid, dueAmount)
        transactionDao.insertDailyEntry(
            DailyEntry(
                shopId = shopId,
                entryType = "Purchase",
                amount = purchasePrice,
                description = "Purchase: $brand $model (IMEI: ${imei1.trim()}) from ${sellerName.trim()}",
                paymentMode = paymentMode,
                cashPart = cashPaid,
                bankPart = bankPaid,
                duePart = dueAmount,
                person = sellerName.trim(),
                imei = imei1.trim(),
                timestamp = now,
                userId = user.id,
                userName = user.name
            )
        )

        // 6. Audit Log
        auditDao.insertLog(
            AuditLog(
                shopId = shopId,
                action = "CREATE",
                entityType = "PURCHASE",
                entityId = mobileId.toString(),
                details = "Purchased $brand $model (IMEI: $imei1) for ₹$purchasePrice [Cash: ₹$cashPaid, Bank: ₹$bankPaid, Due: ₹$dueAmount]",
                userId = user.id,
                userName = user.name,
                timestamp = now
            )
        )

        return mobileId
    }

    /**
     * 2. SALE: ENTER ONCE -> AUTOMATICALLY UPDATE EVERYTHING
     * Removes mobile from Stock (marked SOLD), creates Mobile OUT, updates Cash/Bank/Due,
     * creates Daily Entry, calculates and records Profit/Loss.
     */
    suspend fun recordSale(
        mobile: MobileItem,
        customerName: String,
        customerMobile: String,
        customerAddress: String,
        salePrice: Double,
        cashPaid: Double,
        bankPaid: Double,
        dueAmount: Double,
        paymentRef: String,
        user: User
    ): Long {
        val now = System.currentTimeMillis()
        val profitOrLoss = salePrice - mobile.totalCost

        // 1. Mark mobile as SOLD
        val updatedMobile = mobile.copy(
            status = "SOLD",
            updatedAt = now
        )
        mobileDao.updateMobile(updatedMobile)

        // 2. Insert Mobile OUT Register
        mobileDao.insertMovement(
            MobileMovement(
                shopId = mobile.shopId,
                imei = mobile.imei1,
                brandModel = "${mobile.brand} ${mobile.model}",
                direction = "OUT",
                reason = "Sale",
                personName = customerName.trim(),
                personMobile = customerMobile.trim(),
                value = salePrice,
                timestamp = now,
                userId = user.id,
                userName = user.name,
                notes = "Sold to customer. Profit: ₹$profitOrLoss"
            )
        )

        // 3. Insert Sale Record
        val saleRecord = SaleRecord(
            shopId = mobile.shopId,
            mobileId = mobile.id,
            imei = mobile.imei1,
            brandModel = "${mobile.brand} ${mobile.model}",
            customerName = customerName.trim(),
            customerMobile = customerMobile.trim(),
            customerAddress = customerAddress.trim(),
            purchasePrice = mobile.purchasePrice,
            repairCost = mobile.totalRepairCost,
            totalCost = mobile.totalCost,
            salePrice = salePrice,
            profitOrLoss = profitOrLoss,
            cashPaid = cashPaid,
            bankPaid = bankPaid,
            dueAmount = dueAmount,
            paymentRef = paymentRef.trim(),
            timestamp = now,
            userId = user.id,
            userName = user.name
        )
        val saleId = transactionDao.insertSale(saleRecord)

        // 4. Update Cash & Bank Ledgers
        if (cashPaid > 0) {
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = mobile.shopId,
                    type = "CASH_IN",
                    amount = cashPaid,
                    category = "Sale",
                    referenceImei = mobile.imei1,
                    referencePerson = customerName.trim(),
                    timestamp = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Cash received for ${mobile.brand} ${mobile.model}"
                )
            )
        }
        if (bankPaid > 0) {
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = mobile.shopId,
                    type = "BANK_IN",
                    amount = bankPaid,
                    category = "Sale",
                    referenceImei = mobile.imei1,
                    referencePerson = customerName.trim(),
                    bankOrUpiDetails = paymentRef.trim(),
                    timestamp = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Bank/Online received for ${mobile.brand} ${mobile.model}"
                )
            )
        }

        // 5. Update Due (LENA HAI - Money shop has to receive from customer)
        if (dueAmount > 0) {
            dueDao.insertDue(
                DueRecord(
                    shopId = mobile.shopId,
                    dueDirection = "LENA_HAI",
                    personName = customerName.trim(),
                    personMobile = customerMobile.trim(),
                    personRole = "CUSTOMER",
                    relatedImei = mobile.imei1,
                    relatedTransactionType = "SALE",
                    originalAmount = dueAmount,
                    remainingAmount = dueAmount,
                    createdAt = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Sale receivable for ${mobile.brand} ${mobile.model}"
                )
            )
        }

        // 6. Add Daily Entry
        val paymentMode = determinePaymentMode(cashPaid, bankPaid, dueAmount)
        transactionDao.insertDailyEntry(
            DailyEntry(
                shopId = mobile.shopId,
                entryType = "Sale",
                amount = salePrice,
                description = "Sale: ${mobile.brand} ${mobile.model} (IMEI: ${mobile.imei1}) to ${customerName.trim()} [Cost: ₹${mobile.totalCost}, Profit: ₹$profitOrLoss]",
                paymentMode = paymentMode,
                cashPart = cashPaid,
                bankPart = bankPaid,
                duePart = dueAmount,
                person = customerName.trim(),
                imei = mobile.imei1,
                timestamp = now,
                userId = user.id,
                userName = user.name
            )
        )

        // 7. Audit Log
        auditDao.insertLog(
            AuditLog(
                shopId = mobile.shopId,
                action = "CREATE",
                entityType = "SALE",
                entityId = saleId.toString(),
                details = "Sold ${mobile.brand} ${mobile.model} (IMEI: ${mobile.imei1}) to $customerName for ₹$salePrice [Profit: ₹$profitOrLoss]",
                userId = user.id,
                userName = user.name,
                timestamp = now
            )
        )

        return saleId
    }

    /**
     * 3. REPAIR: Links to IMEI, increases totalRepairCost & totalCost, updates status,
     * updates Cash/Bank/Due and Daily Entry.
     */
    suspend fun recordRepair(
        mobile: MobileItem,
        repairDetails: String,
        technicianOrVendor: String,
        cost: Double,
        cashPaid: Double,
        bankPaid: Double,
        dueAmount: Double,
        paymentRef: String,
        markAsCompleted: Boolean,
        notes: String,
        user: User
    ): Long {
        val now = System.currentTimeMillis()

        // 1. Insert Repair record
        val repairId = transactionDao.insertRepair(
            RepairRecord(
                shopId = mobile.shopId,
                mobileId = mobile.id,
                imei = mobile.imei1,
                brandModel = "${mobile.brand} ${mobile.model}",
                repairDetails = repairDetails.trim(),
                technicianOrVendor = technicianOrVendor.trim(),
                cost = cost,
                cashPaid = cashPaid,
                bankPaid = bankPaid,
                dueAmount = dueAmount,
                paymentRef = paymentRef.trim(),
                timestamp = now,
                userId = user.id,
                userName = user.name,
                isCompleted = markAsCompleted,
                notes = notes.trim()
            )
        )

        // 2. Update Mobile Total Cost & Status
        val updatedRepairCost = mobile.totalRepairCost + cost
        val updatedTotalCost = mobile.purchasePrice + updatedRepairCost
        val updatedStatus = if (markAsCompleted) "IN_STOCK" else "REPAIRING"

        val updatedMobile = mobile.copy(
            totalRepairCost = updatedRepairCost,
            totalCost = updatedTotalCost,
            status = updatedStatus,
            updatedAt = now
        )
        mobileDao.updateMobile(updatedMobile)

        // 3. Update Cash & Bank
        if (cashPaid > 0) {
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = mobile.shopId,
                    type = "CASH_OUT",
                    amount = cashPaid,
                    category = "Repair",
                    referenceImei = mobile.imei1,
                    referencePerson = technicianOrVendor.trim(),
                    timestamp = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Repair paid to $technicianOrVendor for ${mobile.brand} ${mobile.model}"
                )
            )
        }
        if (bankPaid > 0) {
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = mobile.shopId,
                    type = "BANK_OUT",
                    amount = bankPaid,
                    category = "Repair",
                    referenceImei = mobile.imei1,
                    referencePerson = technicianOrVendor.trim(),
                    bankOrUpiDetails = paymentRef.trim(),
                    timestamp = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Online repair paid to $technicianOrVendor"
                )
            )
        }

        // 4. If Due (DENA HAI)
        if (dueAmount > 0) {
            dueDao.insertDue(
                DueRecord(
                    shopId = mobile.shopId,
                    dueDirection = "DENA_HAI",
                    personName = technicianOrVendor.trim(),
                    personMobile = "",
                    personRole = "VENDOR",
                    relatedImei = mobile.imei1,
                    relatedTransactionType = "REPAIR",
                    originalAmount = dueAmount,
                    remainingAmount = dueAmount,
                    createdAt = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Repair payable for ${mobile.brand} ${mobile.model}"
                )
            )
        }

        // 5. Daily Entry
        val paymentMode = determinePaymentMode(cashPaid, bankPaid, dueAmount)
        transactionDao.insertDailyEntry(
            DailyEntry(
                shopId = mobile.shopId,
                entryType = "Repair",
                amount = cost,
                description = "Repair: ${mobile.brand} ${mobile.model} ($repairDetails) by $technicianOrVendor",
                paymentMode = paymentMode,
                cashPart = cashPaid,
                bankPart = bankPaid,
                duePart = dueAmount,
                person = technicianOrVendor.trim(),
                imei = mobile.imei1,
                timestamp = now,
                userId = user.id,
                userName = user.name
            )
        )

        // 6. Audit Log
        auditDao.insertLog(
            AuditLog(
                shopId = mobile.shopId,
                action = "CREATE",
                entityType = "REPAIR",
                entityId = repairId.toString(),
                details = "Repair added for ${mobile.brand} ${mobile.model}: $repairDetails, cost ₹$cost",
                userId = user.id,
                userName = user.name,
                timestamp = now
            )
        )

        return repairId
    }

    /**
     * Mark repair as finished (turns status back from REPAIRING to IN_STOCK).
     */
    suspend fun completeRepair(mobile: MobileItem, user: User) {
        val updated = mobile.copy(status = "IN_STOCK", updatedAt = System.currentTimeMillis())
        mobileDao.updateMobile(updated)
        auditDao.insertLog(
            AuditLog(
                shopId = mobile.shopId,
                action = "UPDATE",
                entityType = "MOBILE_STATUS",
                entityId = mobile.id.toString(),
                details = "Repair marked complete for ${mobile.brand} ${mobile.model} (IMEI: ${mobile.imei1}). Status back to IN_STOCK",
                userId = user.id,
                userName = user.name
            )
        )
    }

    /**
     * 4. RETURN: Customer Returns Sold Mobile OR Shop Returns Mobile to Seller
     */
    suspend fun recordReturn(
        shopId: String,
        returnType: String, // "CUSTOMER_RETURN" or "SHOP_TO_SELLER"
        imei: String,
        brandModel: String,
        personName: String,
        personMobile: String,
        reason: String,
        refundAmount: Double,
        cashAmount: Double,
        bankAmount: Double,
        dueAmount: Double,
        notes: String,
        user: User
    ): Long {
        val now = System.currentTimeMillis()
        val mobile = mobileDao.findByImei(imei)

        val returnId = transactionDao.insertReturn(
            ReturnRecord(
                shopId = shopId,
                returnType = returnType,
                imei = imei.trim(),
                brandModel = brandModel.trim(),
                personName = personName.trim(),
                personMobile = personMobile.trim(),
                reason = reason.trim(),
                refundAmount = refundAmount,
                cashAmount = cashAmount,
                bankAmount = bankAmount,
                dueAmount = dueAmount,
                timestamp = now,
                userId = user.id,
                userName = user.name,
                notes = notes.trim()
            )
        )

        if (returnType == "CUSTOMER_RETURN") {
            // Mobile comes back to shop stock
            if (mobile != null) {
                mobileDao.updateMobile(mobile.copy(status = "IN_STOCK", updatedAt = now))
            }
            mobileDao.insertMovement(
                MobileMovement(
                    shopId = shopId,
                    imei = imei.trim(),
                    brandModel = brandModel.trim(),
                    direction = "IN",
                    reason = "Customer Return",
                    personName = personName.trim(),
                    personMobile = personMobile.trim(),
                    value = refundAmount,
                    timestamp = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Customer returned mobile: $reason"
                )
            )
            // Shop pays back customer (Cash/Bank Out)
            if (cashAmount > 0) {
                transactionDao.insertCashBankTransaction(
                    CashBankTransaction(
                        shopId = shopId,
                        type = "CASH_OUT",
                        amount = cashAmount,
                        category = "Return",
                        referenceImei = imei.trim(),
                        referencePerson = personName.trim(),
                        timestamp = now,
                        userId = user.id,
                        userName = user.name,
                        notes = "Refund cash paid to customer for return"
                    )
                )
            }
            if (bankAmount > 0) {
                transactionDao.insertCashBankTransaction(
                    CashBankTransaction(
                        shopId = shopId,
                        type = "BANK_OUT",
                        amount = bankAmount,
                        category = "Return",
                        referenceImei = imei.trim(),
                        referencePerson = personName.trim(),
                        timestamp = now,
                        userId = user.id,
                        userName = user.name,
                        notes = "Refund online paid to customer"
                    )
                )
            }
        } else {
            // SHOP_TO_SELLER: Mobile leaves shop
            if (mobile != null) {
                mobileDao.updateMobile(mobile.copy(status = "RETURNED", updatedAt = now))
            }
            mobileDao.insertMovement(
                MobileMovement(
                    shopId = shopId,
                    imei = imei.trim(),
                    brandModel = brandModel.trim(),
                    direction = "OUT",
                    reason = "Return to Seller",
                    personName = personName.trim(),
                    personMobile = personMobile.trim(),
                    value = refundAmount,
                    timestamp = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Shop returned mobile to seller: $reason"
                )
            )
            // Shop recovers money from seller (Cash/Bank In)
            if (cashAmount > 0) {
                transactionDao.insertCashBankTransaction(
                    CashBankTransaction(
                        shopId = shopId,
                        type = "CASH_IN",
                        amount = cashAmount,
                        category = "Return",
                        referenceImei = imei.trim(),
                        referencePerson = personName.trim(),
                        timestamp = now,
                        userId = user.id,
                        userName = user.name,
                        notes = "Refund received from seller"
                    )
                )
            }
            if (bankAmount > 0) {
                transactionDao.insertCashBankTransaction(
                    CashBankTransaction(
                        shopId = shopId,
                        type = "BANK_IN",
                        amount = bankAmount,
                        category = "Return",
                        referenceImei = imei.trim(),
                        referencePerson = personName.trim(),
                        timestamp = now,
                        userId = user.id,
                        userName = user.name,
                        notes = "Online refund received from seller"
                    )
                )
            }
        }

        // Daily Entry
        transactionDao.insertDailyEntry(
            DailyEntry(
                shopId = shopId,
                entryType = "Return",
                amount = refundAmount,
                description = "Return ($returnType): $brandModel (IMEI: $imei) with $personName. Reason: $reason",
                paymentMode = determinePaymentMode(cashAmount, bankAmount, dueAmount),
                cashPart = cashAmount,
                bankPart = bankAmount,
                duePart = dueAmount,
                person = personName.trim(),
                imei = imei.trim(),
                timestamp = now,
                userId = user.id,
                userName = user.name
            )
        )

        // Audit Log
        auditDao.insertLog(
            AuditLog(
                shopId = shopId,
                action = "CREATE",
                entityType = "RETURN",
                entityId = returnId.toString(),
                details = "Return recorded ($returnType) for $brandModel (IMEI: $imei), refund ₹$refundAmount",
                userId = user.id,
                userName = user.name,
                timestamp = now
            )
        )

        return returnId
    }

    /**
     * 5. EXCHANGE: Mobile for Mobile Exchange with Money Difference in either direction
     */
    suspend fun recordExchange(
        shopId: String,
        customerName: String,
        customerMobile: String,
        incomingImei: String,
        incomingBrand: String,
        incomingModel: String,
        incomingRam: String,
        incomingStorage: String,
        incomingCondition: String,
        incomingValue: Double,
        outgoingMobile: MobileItem,
        outgoingValue: Double,
        differenceAmount: Double, // outgoingValue - incomingValue
        customerPaidCash: Double,
        customerPaidBank: Double,
        shopPaidCash: Double,
        shopPaidBank: Double,
        dueAmount: Double,
        notes: String,
        user: User
    ): Long {
        val now = System.currentTimeMillis()

        // 1. Mark outgoing mobile as EXCHANGED (leaves stock)
        val updatedOutgoing = outgoingMobile.copy(status = "EXCHANGED", updatedAt = now)
        mobileDao.updateMobile(updatedOutgoing)

        // 2. Insert incoming mobile into stock
        val incomingMobileItem = MobileItem(
            imei1 = incomingImei.trim(),
            brand = incomingBrand.trim(),
            model = incomingModel.trim(),
            ram = incomingRam.trim(),
            storage = incomingStorage.trim(),
            condition = incomingCondition,
            purchasePrice = incomingValue,
            totalRepairCost = 0.0,
            totalCost = incomingValue,
            status = "IN_STOCK",
            purchaseDate = now,
            sellerName = customerName.trim(),
            sellerMobile = customerMobile.trim(),
            notes = "Received via exchange for ${outgoingMobile.brand} ${outgoingMobile.model}",
            shopId = shopId,
            createdAt = now,
            createdBy = user.name,
            updatedAt = now
        )
        mobileDao.insertMobile(incomingMobileItem)

        // 3. Movement IN for Incoming
        mobileDao.insertMovement(
            MobileMovement(
                shopId = shopId,
                imei = incomingImei.trim(),
                brandModel = "$incomingBrand $incomingModel",
                direction = "IN",
                reason = "Exchange In",
                personName = customerName.trim(),
                personMobile = customerMobile.trim(),
                value = incomingValue,
                timestamp = now,
                userId = user.id,
                userName = user.name,
                notes = "Incoming mobile via exchange"
            )
        )

        // 4. Movement OUT for Outgoing
        mobileDao.insertMovement(
            MobileMovement(
                shopId = shopId,
                imei = outgoingMobile.imei1,
                brandModel = "${outgoingMobile.brand} ${outgoingMobile.model}",
                direction = "OUT",
                reason = "Exchange Out",
                personName = customerName.trim(),
                personMobile = customerMobile.trim(),
                value = outgoingValue,
                timestamp = now,
                userId = user.id,
                userName = user.name,
                notes = "Outgoing mobile given in exchange"
            )
        )

        // 5. Money Reconciliation:
        // If customer pays shop
        if (customerPaidCash > 0) {
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = shopId,
                    type = "CASH_IN",
                    amount = customerPaidCash,
                    category = "Exchange",
                    referenceImei = outgoingMobile.imei1,
                    referencePerson = customerName.trim(),
                    timestamp = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Cash received from customer in exchange"
                )
            )
        }
        if (customerPaidBank > 0) {
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = shopId,
                    type = "BANK_IN",
                    amount = customerPaidBank,
                    category = "Exchange",
                    referenceImei = outgoingMobile.imei1,
                    referencePerson = customerName.trim(),
                    timestamp = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Online received from customer in exchange"
                )
            )
        }
        // If shop pays customer
        if (shopPaidCash > 0) {
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = shopId,
                    type = "CASH_OUT",
                    amount = shopPaidCash,
                    category = "Exchange",
                    referenceImei = incomingImei.trim(),
                    referencePerson = customerName.trim(),
                    timestamp = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Cash paid to customer in exchange"
                )
            )
        }
        if (shopPaidBank > 0) {
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = shopId,
                    type = "BANK_OUT",
                    amount = shopPaidBank,
                    category = "Exchange",
                    referenceImei = incomingImei.trim(),
                    referencePerson = customerName.trim(),
                    timestamp = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Online paid to customer in exchange"
                )
            )
        }

        // 6. Due if applicable
        if (dueAmount > 0) {
            val dueDirection = if (differenceAmount > 0) "LENA_HAI" else "DENA_HAI"
            dueDao.insertDue(
                DueRecord(
                    shopId = shopId,
                    dueDirection = dueDirection,
                    personName = customerName.trim(),
                    personMobile = customerMobile.trim(),
                    personRole = "CUSTOMER",
                    relatedImei = outgoingMobile.imei1,
                    relatedTransactionType = "EXCHANGE",
                    originalAmount = dueAmount,
                    remainingAmount = dueAmount,
                    createdAt = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Exchange due for $outgoingMobile.brand to $incomingBrand"
                )
            )
        }

        // 7. Insert Exchange record
        val exchangeId = transactionDao.insertExchange(
            ExchangeRecord(
                shopId = shopId,
                customerName = customerName.trim(),
                customerMobile = customerMobile.trim(),
                incomingImei = incomingImei.trim(),
                incomingBrandModel = "$incomingBrand $incomingModel",
                incomingValue = incomingValue,
                outgoingImei = outgoingMobile.imei1,
                outgoingBrandModel = "${outgoingMobile.brand} ${outgoingMobile.model}",
                outgoingValue = outgoingValue,
                differenceAmount = differenceAmount,
                customerPaidCash = customerPaidCash,
                customerPaidBank = customerPaidBank,
                shopPaidCash = shopPaidCash,
                shopPaidBank = shopPaidBank,
                dueAmount = dueAmount,
                timestamp = now,
                userId = user.id,
                userName = user.name,
                notes = notes.trim()
            )
        )

        // 8. Daily Entry
        transactionDao.insertDailyEntry(
            DailyEntry(
                shopId = shopId,
                entryType = "Exchange",
                amount = Math.abs(differenceAmount),
                description = "Exchange: Out ${outgoingMobile.brand} ${outgoingMobile.model} (₹$outgoingValue) ↔ In $incomingBrand $incomingModel (₹$incomingValue) with $customerName",
                person = customerName.trim(),
                imei = "${outgoingMobile.imei1} / $incomingImei",
                timestamp = now,
                userId = user.id,
                userName = user.name
            )
        )

        // 9. Audit Log
        auditDao.insertLog(
            AuditLog(
                shopId = shopId,
                action = "CREATE",
                entityType = "EXCHANGE",
                entityId = exchangeId.toString(),
                details = "Exchange between IMEI ${outgoingMobile.imei1} and $incomingImei. Diff: ₹$differenceAmount",
                userId = user.id,
                userName = user.name,
                timestamp = now
            )
        )

        return exchangeId
    }

    /**
     * 6. DUE PAYMENT: Support partial/full payment in Cash, Bank or Mixed.
     * Partial payment does NOT reset original due date.
     * When fully cleared, status = CLEARED and durationDays is computed.
     */
    suspend fun recordDuePayment(
        due: DueRecord,
        cashAmount: Double,
        bankAmount: Double,
        paymentRef: String,
        notes: String,
        user: User
    ) {
        val now = System.currentTimeMillis()
        val totalPayment = cashAmount + bankAmount
        val newPaid = due.paidAmount + totalPayment
        val newRemaining = maxOf(0.0, due.remainingAmount - totalPayment)

        val isFullyCleared = newRemaining <= 0.001
        val newStatus = if (isFullyCleared) "CLEARED" else "PARTIAL"
        val clearedAt = if (isFullyCleared) now else due.clearedAt
        val durationDays = if (isFullyCleared) {
            val days = ((now - due.createdAt) / (1000L * 60 * 60 * 24)).toInt()
            maxOf(0, days)
        } else due.durationDays

        // 1. Update Due
        val updatedDue = due.copy(
            paidAmount = newPaid,
            remainingAmount = newRemaining,
            status = newStatus,
            clearedAt = clearedAt,
            durationDays = durationDays
        )
        dueDao.updateDue(updatedDue)

        // 2. Insert Payment Record
        dueDao.insertDuePayment(
            DuePayment(
                dueId = due.id,
                shopId = due.shopId,
                amount = totalPayment,
                cashAmount = cashAmount,
                bankAmount = bankAmount,
                paymentRef = paymentRef.trim(),
                timestamp = now,
                userId = user.id,
                userName = user.name,
                remainingAfterPayment = newRemaining,
                notes = notes.trim()
            )
        )

        // 3. Update Cash & Bank Ledgers
        if (due.dueDirection == "LENA_HAI") {
            // Customer is paying shop -> Money IN
            if (cashAmount > 0) {
                transactionDao.insertCashBankTransaction(
                    CashBankTransaction(
                        shopId = due.shopId,
                        type = "CASH_IN",
                        amount = cashAmount,
                        category = "Due Payment",
                        referenceImei = due.relatedImei,
                        referencePerson = due.personName,
                        timestamp = now,
                        userId = user.id,
                        userName = user.name,
                        notes = "Due cleared by ${due.personName}"
                    )
                )
            }
            if (bankAmount > 0) {
                transactionDao.insertCashBankTransaction(
                    CashBankTransaction(
                        shopId = due.shopId,
                        type = "BANK_IN",
                        amount = bankAmount,
                        category = "Due Payment",
                        referenceImei = due.relatedImei,
                        referencePerson = due.personName,
                        bankOrUpiDetails = paymentRef.trim(),
                        timestamp = now,
                        userId = user.id,
                        userName = user.name,
                        notes = "Online due payment from ${due.personName}"
                    )
                )
            }
        } else {
            // Shop is paying vendor/seller -> Money OUT
            if (cashAmount > 0) {
                transactionDao.insertCashBankTransaction(
                    CashBankTransaction(
                        shopId = due.shopId,
                        type = "CASH_OUT",
                        amount = cashAmount,
                        category = "Due Payment",
                        referenceImei = due.relatedImei,
                        referencePerson = due.personName,
                        timestamp = now,
                        userId = user.id,
                        userName = user.name,
                        notes = "Due paid to ${due.personName}"
                    )
                )
            }
            if (bankAmount > 0) {
                transactionDao.insertCashBankTransaction(
                    CashBankTransaction(
                        shopId = due.shopId,
                        type = "BANK_OUT",
                        amount = bankAmount,
                        category = "Due Payment",
                        referenceImei = due.relatedImei,
                        referencePerson = due.personName,
                        bankOrUpiDetails = paymentRef.trim(),
                        timestamp = now,
                        userId = user.id,
                        userName = user.name,
                        notes = "Online due payment to ${due.personName}"
                    )
                )
            }
        }

        // 4. Daily Entry
        transactionDao.insertDailyEntry(
            DailyEntry(
                shopId = due.shopId,
                entryType = "Due Payment",
                amount = totalPayment,
                description = "Due Payment (${due.dueDirection}): ${due.personName}. Paid: ₹$totalPayment, Remaining: ₹$newRemaining",
                paymentMode = determinePaymentMode(cashAmount, bankAmount, 0.0),
                cashPart = cashAmount,
                bankPart = bankAmount,
                person = due.personName,
                imei = due.relatedImei,
                timestamp = now,
                userId = user.id,
                userName = user.name
            )
        )

        // 5. Audit Log
        auditDao.insertLog(
            AuditLog(
                shopId = due.shopId,
                action = "UPDATE",
                entityType = "DUE_PAYMENT",
                entityId = due.id.toString(),
                details = "Due payment of ₹$totalPayment for ${due.personName} (${due.dueDirection}). Status: $newStatus",
                userId = user.id,
                userName = user.name,
                timestamp = now
            )
        )
    }

    /**
     * 7. CASH <-> BANK TRANSFER
     * Transfers money between Cash in Hand and Bank without affecting Income/Expense.
     */
    suspend fun recordCashBankTransfer(
        shopId: String,
        transferType: String, // "CASH_TO_BANK" or "BANK_TO_CASH"
        amount: Double,
        referenceOrNotes: String,
        user: User
    ) {
        val now = System.currentTimeMillis()
        if (transferType == "CASH_TO_BANK") {
            // Cash out, Bank in
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = shopId,
                    type = "CASH_OUT",
                    amount = amount,
                    category = "Transfer",
                    timestamp = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Cash deposited into Bank account"
                )
            )
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = shopId,
                    type = "BANK_IN",
                    amount = amount,
                    category = "Transfer",
                    bankOrUpiDetails = referenceOrNotes.trim(),
                    timestamp = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Deposit received from Cash"
                )
            )
            transactionDao.insertDailyEntry(
                DailyEntry(
                    shopId = shopId,
                    entryType = "Cash/Bank Transfer",
                    amount = amount,
                    description = "Cash deposited into Bank (₹$amount). Ref: $referenceOrNotes",
                    paymentMode = "Cash -> Bank",
                    timestamp = now,
                    userId = user.id,
                    userName = user.name
                )
            )
        } else {
            // Bank out, Cash in
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = shopId,
                    type = "BANK_OUT",
                    amount = amount,
                    category = "Transfer",
                    bankOrUpiDetails = referenceOrNotes.trim(),
                    timestamp = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Bank withdrawal to Cash"
                )
            )
            transactionDao.insertCashBankTransaction(
                CashBankTransaction(
                    shopId = shopId,
                    type = "CASH_IN",
                    amount = amount,
                    category = "Transfer",
                    timestamp = now,
                    userId = user.id,
                    userName = user.name,
                    notes = "Cash received from Bank withdrawal"
                )
            )
            transactionDao.insertDailyEntry(
                DailyEntry(
                    shopId = shopId,
                    entryType = "Cash/Bank Transfer",
                    amount = amount,
                    description = "Cash withdrawn from Bank (₹$amount). Ref: $referenceOrNotes",
                    paymentMode = "Bank -> Cash",
                    timestamp = now,
                    userId = user.id,
                    userName = user.name
                )
            )
        }

        auditDao.insertLog(
            AuditLog(
                shopId = shopId,
                action = "TRANSFER",
                entityType = "CASH_BANK_TRANSFER",
                entityId = shopId,
                details = "Transfer $transferType: ₹$amount by ${user.name}",
                userId = user.id,
                userName = user.name,
                timestamp = now
            )
        )
    }

    /**
     * 8. EXPENSE & FOOD
     */
    suspend fun recordExpense(
        shopId: String,
        category: String,
        amount: Double,
        paymentMode: String, // "Cash" or "Bank/Online"
        description: String,
        staffOrPerson: String,
        isFood: Boolean = false,
        user: User
    ): Long {
        val now = System.currentTimeMillis()
        val expenseId = transactionDao.insertExpense(
            ExpenseRecord(
                shopId = shopId,
                category = category,
                amount = amount,
                paymentMode = paymentMode,
                description = description.trim(),
                staffOrPerson = staffOrPerson.trim(),
                timestamp = now,
                userId = user.id,
                userName = user.name
            )
        )

        val txType = if (paymentMode == "Cash") "CASH_OUT" else "BANK_OUT"
        transactionDao.insertCashBankTransaction(
            CashBankTransaction(
                shopId = shopId,
                type = txType,
                amount = amount,
                category = if (isFood) "Food" else "Expense",
                referencePerson = staffOrPerson.trim(),
                timestamp = now,
                userId = user.id,
                userName = user.name,
                notes = "$category: $description"
            )
        )

        transactionDao.insertDailyEntry(
            DailyEntry(
                shopId = shopId,
                entryType = if (isFood) "Food" else "Expense",
                amount = amount,
                description = "$category: $description ($staffOrPerson)",
                paymentMode = paymentMode,
                cashPart = if (paymentMode == "Cash") amount else 0.0,
                bankPart = if (paymentMode != "Cash") amount else 0.0,
                person = staffOrPerson.trim(),
                timestamp = now,
                userId = user.id,
                userName = user.name
            )
        )

        auditDao.insertLog(
            AuditLog(
                shopId = shopId,
                action = "CREATE",
                entityType = "EXPENSE",
                entityId = expenseId.toString(),
                details = "Expense $category: ₹$amount via $paymentMode",
                userId = user.id,
                userName = user.name,
                timestamp = now
            )
        )

        return expenseId
    }

    /**
     * 9. STAFF ADVANCE & LEAVE
     */
    suspend fun recordStaffAdvance(
        staffId: Long,
        staffName: String,
        shopId: String,
        amount: Double,
        paymentMode: String,
        purpose: String,
        user: User
    ) {
        val now = System.currentTimeMillis()
        staffDao.insertAdvance(
            StaffAdvance(
                staffId = staffId,
                staffName = staffName,
                shopId = shopId,
                amount = amount,
                remainingAdvance = amount,
                paymentMode = paymentMode,
                purpose = purpose.trim(),
                timestamp = now,
                userId = user.id,
                userName = user.name
            )
        )

        val txType = if (paymentMode == "Cash") "CASH_OUT" else "BANK_OUT"
        transactionDao.insertCashBankTransaction(
            CashBankTransaction(
                shopId = shopId,
                type = txType,
                amount = amount,
                category = "Staff Advance",
                referencePerson = staffName,
                timestamp = now,
                userId = user.id,
                userName = user.name,
                notes = "Advance given to $staffName for $purpose"
            )
        )

        transactionDao.insertDailyEntry(
            DailyEntry(
                shopId = shopId,
                entryType = "Staff Advance",
                amount = amount,
                description = "Staff Advance: $staffName for $purpose",
                paymentMode = paymentMode,
                cashPart = if (paymentMode == "Cash") amount else 0.0,
                bankPart = if (paymentMode != "Cash") amount else 0.0,
                person = staffName,
                timestamp = now,
                userId = user.id,
                userName = user.name
            )
        )

        auditDao.insertLog(
            AuditLog(
                shopId = shopId,
                action = "CREATE",
                entityType = "STAFF_ADVANCE",
                entityId = staffId.toString(),
                details = "Advance given to $staffName: ₹$amount",
                userId = user.id,
                userName = user.name,
                timestamp = now
            )
        )
    }

    suspend fun recordStaffLeave(
        staffId: Long,
        staffName: String,
        shopId: String,
        days: Int,
        reason: String,
        isPaid: Boolean,
        user: User
    ) {
        val now = System.currentTimeMillis()
        staffDao.insertLeave(
            StaffLeave(
                staffId = staffId,
                staffName = staffName,
                shopId = shopId,
                startDate = now,
                days = days,
                reason = reason.trim(),
                isPaid = isPaid,
                timestamp = now,
                userId = user.id,
                userName = user.name
            )
        )

        transactionDao.insertDailyEntry(
            DailyEntry(
                shopId = shopId,
                entryType = "Staff Leave",
                amount = 0.0,
                description = "Staff Leave: $staffName for $days days (${if (isPaid) "Paid" else "Unpaid"}). Reason: $reason",
                paymentMode = "None",
                person = staffName,
                timestamp = now,
                userId = user.id,
                userName = user.name
            )
        )
    }

    /**
     * Soft-reversal / cancellation of transaction (Never silently erase history).
     */
    suspend fun reverseDailyEntry(entry: DailyEntry, reason: String, user: User) {
        val now = System.currentTimeMillis()
        transactionDao.updateDailyEntry(entry.copy(isReversed = true))

        auditDao.insertLog(
            AuditLog(
                shopId = entry.shopId,
                action = "REVERSE",
                entityType = "DAILY_ENTRY",
                entityId = entry.id.toString(),
                details = "Reversed entry [${entry.entryType}: ₹${entry.amount}]. Reason: $reason",
                userId = user.id,
                userName = user.name,
                timestamp = now
            )
        )
    }

    private fun determinePaymentMode(cash: Double, bank: Double, due: Double): String {
        return when {
            cash > 0 && bank > 0 && due > 0 -> "Cash + Bank + Due"
            cash > 0 && bank > 0 -> "Cash + Bank"
            cash > 0 && due > 0 -> "Cash + Due"
            bank > 0 && due > 0 -> "Bank + Due"
            cash > 0 -> "Cash"
            bank > 0 -> "Bank/Online"
            due > 0 -> "Due"
            else -> "None"
        }
    }
}

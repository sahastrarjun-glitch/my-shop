package com.example.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.example.ui.components.ShopTopAppBar
import com.example.ui.components.SwitchUserDialog
import com.example.ui.screens.cashbank.CashBankScreen
import com.example.ui.screens.daily.DailyEntryScreen
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.dues.DueScreen
import com.example.ui.screens.more.MoreScreen
import com.example.ui.screens.movements.MovementsScreen
import com.example.ui.screens.reports.ReportsScreen
import com.example.ui.screens.staff.StaffScreen
import com.example.ui.screens.stock.StockScreen
import com.example.ui.screens.transactions.*
import com.example.ui.viewmodel.ShopViewModel

enum class NavTab(val route: String, val label: String, val icon: ImageVector) {
    DASHBOARD("dashboard", "Dashboard", Icons.Default.Dashboard),
    STOCK("stock", "Stock", Icons.Default.PhoneAndroid),
    DAILY("daily", "Daily Entry", Icons.Default.MenuBook),
    DUES("dues", "Dues", Icons.Default.AccountBalance),
    MORE("more", "More", Icons.Default.GridView)
}

@Composable
fun MainApp(viewModel: ShopViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: NavTab.DASHBOARD.route

    val currentShop by viewModel.currentShop.collectAsStateWithLifecycle()
    val allShops by viewModel.allShops.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()

    var showSwitchUserDialog by remember { mutableStateOf(false) }

    val isTopLevelRoute = currentRoute in NavTab.values().map { it.route }

    Scaffold(
        topBar = {
            if (isTopLevelRoute) {
                ShopTopAppBar(
                    currentShop = currentShop,
                    allShops = allShops,
                    currentUser = currentUser,
                    onShopSelected = { shopId ->
                        viewModel.switchShop(shopId)
                    },
                    onSwitchUserClicked = {
                        showSwitchUserDialog = true
                    }
                )
            }
        },
        bottomBar = {
            if (isTopLevelRoute) {
                NavigationBar {
                    NavTab.values().forEach { tab ->
                        val selected = currentRoute == tab.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(tab.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = NavTab.DASHBOARD.route,
            modifier = Modifier.padding(paddingValues)
        ) {
            composable(NavTab.DASHBOARD.route) {
                DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToPurchase = { navController.navigate("purchase") },
                    onNavigateToSale = { navController.navigate("sale") },
                    onNavigateToRepair = { navController.navigate("repair") },
                    onNavigateToExchange = { navController.navigate("exchange") },
                    onNavigateToReturn = { navController.navigate("return") },
                    onNavigateToDues = { navController.navigate(NavTab.DUES.route) },
                    onNavigateToCashBank = { navController.navigate("cash_bank") },
                    onNavigateToStock = { navController.navigate(NavTab.STOCK.route) },
                    onNavigateToDailyEntry = { navController.navigate(NavTab.DAILY.route) },
                    onNavigateToReports = { navController.navigate("reports") }
                )
            }

            composable(NavTab.STOCK.route) {
                StockScreen(
                    viewModel = viewModel,
                    onNavigateToPurchase = { navController.navigate("purchase") }
                )
            }

            composable(NavTab.DAILY.route) {
                DailyEntryScreen(viewModel = viewModel)
            }

            composable(NavTab.DUES.route) {
                DueScreen(viewModel = viewModel)
            }

            composable(NavTab.MORE.route) {
                MoreScreen(
                    viewModel = viewModel,
                    onNavigateToMovements = { navController.navigate("movements") },
                    onNavigateToCashBank = { navController.navigate("cash_bank") },
                    onNavigateToReports = { navController.navigate("reports") },
                    onNavigateToStaff = { navController.navigate("staff") },
                    onNavigateToPurchase = { navController.navigate("purchase") },
                    onNavigateToSale = { navController.navigate("sale") },
                    onNavigateToRepair = { navController.navigate("repair") },
                    onNavigateToExchange = { navController.navigate("exchange") },
                    onNavigateToReturn = { navController.navigate("return") },
                    onSwitchUser = { showSwitchUserDialog = true }
                )
            }

            // Dedicated Transaction Screens
            composable("purchase") {
                PurchaseScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("sale") {
                SaleScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("repair") {
                RepairScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("exchange") {
                ExchangeScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("return") {
                ReturnScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("cash_bank") {
                CashBankScreen(viewModel = viewModel)
            }

            composable("reports") {
                ReportsScreen(viewModel = viewModel)
            }

            composable("movements") {
                MovementsScreen(viewModel = viewModel)
            }

            composable("staff") {
                StaffScreen(viewModel = viewModel)
            }
        }
    }

    if (showSwitchUserDialog) {
        SwitchUserDialog(
            currentUser = currentUser,
            allUsers = allUsers,
            onDismiss = { showSwitchUserDialog = false },
            onVerifyAndSwitch = { user, pin ->
                val success = viewModel.verifyPin(user.id, pin)
                if (success) {
                    viewModel.switchUser(user)
                }
                success
            }
        )
    }
}

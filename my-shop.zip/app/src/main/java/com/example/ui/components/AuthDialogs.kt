package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.User
import kotlinx.coroutines.launch

@Composable
fun SwitchUserDialog(
    currentUser: User,
    allUsers: List<User>,
    onDismiss: () -> Unit,
    onVerifyAndSwitch: suspend (User, String) -> Boolean
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedUser by remember { mutableStateOf<User?>(null) }
    var pin by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isVerifying by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Authorised Users", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column {
                Text(
                    "Select one of the 3 authorised shop users and enter your security PIN:",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))

                allUsers.forEach { user ->
                    val isSelected = selectedUser?.id == user.id
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable {
                                selectedUser = user
                                errorMessage = null
                            }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(12.dp)
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = {
                                    selectedUser = user
                                    errorMessage = null
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(user.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(
                                    "Role: ${user.role} ${if (user.assignedShopId != null) "• (${user.assignedShopId})" else "• (All Shops)"}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }

                if (selectedUser != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = pin,
                        onValueChange = { if (it.length <= 6) pin = it },
                        label = { Text("Enter 4-Digit Security PIN") },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        isError = errorMessage != null,
                        supportingText = {
                            if (errorMessage != null) {
                                Text(errorMessage!!, color = MaterialTheme.colorScheme.error)
                            } else {
                                Text("Default PINs: Admin=1234, Mgr1=1111, Mgr2=2222", fontSize = 10.sp)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                enabled = selectedUser != null && pin.isNotBlank() && !isVerifying,
                onClick = {
                    val user = selectedUser ?: return@Button
                    isVerifying = true
                    coroutineScope.launch {
                        val ok = onVerifyAndSwitch(user, pin)
                        isVerifying = false
                        if (ok) {
                            onDismiss()
                        } else {
                            errorMessage = "Invalid PIN for ${user.name}"
                        }
                    }
                }
            ) {
                Text(if (isVerifying) "Verifying..." else "Switch User")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

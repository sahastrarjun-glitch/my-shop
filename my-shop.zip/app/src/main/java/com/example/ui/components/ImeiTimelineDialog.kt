package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MobileItem
import com.example.data.model.MobileMovement
import com.example.data.model.RepairRecord
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImeiTimelineDialog(
    mobile: MobileItem,
    movements: List<MobileMovement>,
    repairs: List<RepairRecord>,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.85f),
        title = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PhoneAndroid,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${mobile.brand} ${mobile.model}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "IMEI 1: ${mobile.imei1} ${if (mobile.imei2.isNotBlank()) "| IMEI 2: ${mobile.imei2}" else ""}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1. Current Snapshot Card
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                StatusBadge(mobile.status)
                                Text(
                                    text = "Condition: ${mobile.condition}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("Purchase Price", fontSize = 11.sp, color = Color.DarkGray)
                                    Text(
                                        Formatters.formatRupees(mobile.purchasePrice),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                                Column {
                                    Text("Repair Cost", fontSize = 11.sp, color = Color.DarkGray)
                                    Text(
                                        Formatters.formatRupees(mobile.totalRepairCost),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (mobile.totalRepairCost > 0) DenaHaiRed else Color.Black
                                    )
                                }
                                Column {
                                    Text("Total Cost", fontSize = 11.sp, color = Color.DarkGray)
                                    Text(
                                        Formatters.formatRupees(mobile.totalCost),
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            if (mobile.sellerName.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    "Acquired from: ${mobile.sellerName} (${mobile.sellerMobile})",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                                if (mobile.sellerAadhaarMasked.isNotBlank()) {
                                    Text(
                                        "Seller Aadhaar: ${mobile.sellerAadhaarMasked}",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }

                // 2. Repairs Breakdown Section (if any)
                if (repairs.isNotEmpty()) {
                    item {
                        Text(
                            "Repairs History (${repairs.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    items(repairs) { repair ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(8.dp),
                            elevation = CardDefaults.cardElevation(1.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        repair.repairDetails,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        Formatters.formatRupees(repair.cost),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = DenaHaiRed
                                    )
                                }
                                Text(
                                    "By: ${repair.technicianOrVendor} • ${Formatters.formatDate(repair.timestamp)}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }

                // 3. Movement & Lifecycle Timeline
                item {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "Lifetime Movement Timeline",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                items(movements) { mov ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Top
                    ) {
                        // Dot indicator
                        Box(
                            modifier = Modifier
                                .padding(top = 4.dp)
                                .size(12.dp)
                                .background(
                                    if (mov.direction == "IN") LenaHaiGreen else DenaHaiRed,
                                    CircleShape
                                )
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${mov.reason} (${mov.direction})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (mov.direction == "IN") LenaHaiGreen else DenaHaiRed
                                )
                                Text(
                                    text = Formatters.formatRupees(mov.value),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                            Text(
                                text = "Person: ${mov.personName} ${if (mov.personMobile.isNotBlank()) "(${mov.personMobile})" else ""}",
                                fontSize = 12.sp
                            )
                            Text(
                                text = "${Formatters.formatDate(mov.timestamp)} • User: ${mov.userName}",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                            if (mov.notes.isNotBlank()) {
                                Text(
                                    text = "Notes: ${mov.notes}",
                                    fontSize = 10.sp,
                                    color = Color.DarkGray
                                )
                            }
                            HorizontalDivider(modifier = Modifier.padding(top = 8.dp), color = Color.LightGray.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

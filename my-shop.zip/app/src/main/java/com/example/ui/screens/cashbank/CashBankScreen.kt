package com.example.ui.screens.cashbank

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CashBankTransaction
import com.example.ui.components.Formatters
import com.example.ui.screens.daily.CashBankTransferDialog
import com.example.ui.theme.DenaHaiRed
import com.example.ui.theme.LenaHaiGreen
import com.example.ui.theme.ShopPrimary
import com.example.ui.viewmodel.ShopViewModel
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CashBankScreen(
    viewModel: ShopViewModel
) {
    val currentShop by viewModel.currentShop.collectAsStateWithLifecycle()
    val transactions by viewModel.cashBankTransactions.collectAsStateWithLifecycle()
    val metrics by viewModel.dashboardMetrics.collectAsStateWithLifecycle()

    var showEditOpeningDialog by remember { mutableStateOf(false) }
    var showTransferDialog by remember { mutableStateOf(false) }
    var showAddMoneyDialog by remember { mutableStateOf(false) }
    var showReduceMoneyDialog by remember { mutableStateOf(false) }

    val startOfToday = remember {
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    val todayCashIn = transactions.filter { it.type == "CASH_IN" && it.timestamp >= startOfToday }.sumOf { it.amount }
    val todayCashOut = transactions.filter { it.type == "CASH_OUT" && it.timestamp >= startOfToday }.sumOf { it.amount }

    val todayBankIn = transactions.filter { it.type == "BANK_IN" && it.timestamp >= startOfToday }.sumOf { it.amount }
    val todayBankOut = transactions.filter { it.type == "BANK_OUT" && it.timestamp >= startOfToday }.sumOf { it.amount }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Total Available Banner
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("TOTAL MONEY AVAILABLE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(
                            Formatters.formatRupees(metrics.totalMoneyAvailable),
                            fontWeight = FontWeight.Black,
                            fontSize = 24.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    OutlinedButton(
                        onClick = { showEditOpeningDialog = true },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Set Opening", fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Cash & Bank Split Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Cash in Hand
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(2.dp),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Payments, contentDescription = null, tint = LenaHaiGreen, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Cash in Hand", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        Formatters.formatRupees(metrics.cashInHand),
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = Color(0xFF15803D)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Opening: ${Formatters.formatRupees(currentShop.openingCash)}", fontSize = 10.sp, color = Color.Gray)
                    Text("Today In: +${Formatters.formatRupees(todayCashIn)}", fontSize = 10.sp, color = LenaHaiGreen)
                    Text("Today Out: -${Formatters.formatRupees(todayCashOut)}", fontSize = 10.sp, color = DenaHaiRed)
                }
            }

            // Bank / Online
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(2.dp),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccountBalance, contentDescription = null, tint = ShopPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Bank / Online", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        Formatters.formatRupees(metrics.bankBalance),
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = ShopPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Opening: ${Formatters.formatRupees(currentShop.openingBank)}", fontSize = 10.sp, color = Color.Gray)
                    Text("Today In: +${Formatters.formatRupees(todayBankIn)}", fontSize = 10.sp, color = LenaHaiGreen)
                    Text("Today Out: -${Formatters.formatRupees(todayBankOut)}", fontSize = 10.sp, color = DenaHaiRed)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Action Buttons Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { showTransferDialog = true },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.CompareArrows, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Deposit / Withdraw", fontSize = 11.sp)
            }

            OutlinedButton(
                onClick = { showAddMoneyDialog = true },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Money", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text("Cash & Bank Ledger Transactions", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(6.dp))

        if (transactions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("No cash or bank transactions yet", color = Color.Gray, fontSize = 13.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                items(transactions) { tx ->
                    CashBankTxCard(tx = tx)
                }
            }
        }
    }

    if (showTransferDialog) {
        CashBankTransferDialog(
            onDismiss = { showTransferDialog = false },
            onTransfer = { type, amount, ref ->
                viewModel.recordCashBankTransfer(
                    transferType = type,
                    amount = amount,
                    ref = ref,
                    onSuccess = { showTransferDialog = false },
                    onError = {}
                )
            }
        )
    }

    if (showEditOpeningDialog) {
        var cashText by remember { mutableStateOf(currentShop.openingCash.toString()) }
        var bankText by remember { mutableStateOf(currentShop.openingBank.toString()) }

        AlertDialog(
            onDismissRequest = { showEditOpeningDialog = false },
            title = { Text("Update Opening Balances") },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = cashText,
                        onValueChange = { cashText = it },
                        label = { Text("Opening Cash (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = bankText,
                        onValueChange = { bankText = it },
                        label = { Text("Opening Bank / Online (₹)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val cash = cashText.toDoubleOrNull() ?: 0.0
                        val bank = bankText.toDoubleOrNull() ?: 0.0
                        viewModel.updateOpeningBalances(cash, bank) {
                            showEditOpeningDialog = false
                        }
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditOpeningDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showAddMoneyDialog) {
        var addAmountText by remember { mutableStateOf("") }
        var targetMode by remember { mutableStateOf("Cash") }
        var reasonText by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddMoneyDialog = false },
            title = { Text("Add Money to Shop Balance") },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = addAmountText,
                        onValueChange = { addAmountText = it },
                        label = { Text("Amount (₹)*") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = targetMode == "Cash",
                            onClick = { targetMode = "Cash" },
                            label = { Text("Add to Cash") }
                        )
                        FilterChip(
                            selected = targetMode == "Bank",
                            onClick = { targetMode = "Bank" },
                            label = { Text("Add to Bank") }
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = reasonText,
                        onValueChange = { reasonText = it },
                        label = { Text("Reason (e.g. Owner Capital Injection)*") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = addAmountText.toDoubleOrNull() ?: 0.0
                        if (amt > 0 && reasonText.isNotBlank()) {
                            viewModel.recordExpense(
                                category = "Capital Inflow",
                                amount = amt,
                                paymentMode = targetMode,
                                description = "Added funds: $reasonText",
                                staffOrPerson = "Owner",
                                isFood = false,
                                onSuccess = { showAddMoneyDialog = false },
                                onError = {}
                            )
                        }
                    }
                ) { Text("Add") }
            },
            dismissButton = {
                TextButton(onClick = { showAddMoneyDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun CashBankTxCard(tx: CashBankTransaction) {
    val isIn = tx.type in listOf("CASH_IN", "BANK_IN")
    val isCash = tx.type in listOf("CASH_IN", "CASH_OUT")

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isCash) "💵 CASH" else "🏦 BANK",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = if (isCash) Color(0xFF0D9488) else ShopPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = tx.category,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
                if (tx.notes.isNotBlank()) {
                    Text(text = tx.notes, fontSize = 11.sp, color = Color.DarkGray)
                }
                Text(
                    text = "${Formatters.formatDate(tx.timestamp)} • ${tx.userName}",
                    fontSize = 10.sp,
                    color = Color.Gray
                )
            }

            Text(
                text = (if (isIn) "+ " else "- ") + Formatters.formatRupees(tx.amount),
                fontWeight = FontWeight.Black,
                fontSize = 15.sp,
                color = if (isIn) LenaHaiGreen else DenaHaiRed
            )
        }
    }
}

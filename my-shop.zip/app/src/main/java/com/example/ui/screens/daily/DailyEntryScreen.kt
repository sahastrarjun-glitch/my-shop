package com.example.ui.screens.daily

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.DailyEntry
import com.example.ui.components.Formatters
import com.example.ui.screens.dashboard.DailyEntryCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.ShopViewModel
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyEntryScreen(
    viewModel: ShopViewModel
) {
    val entries by viewModel.dailyEntries.collectAsStateWithLifecycle()
    val currentShop by viewModel.currentShop.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()

    var selectedFilterType by remember { mutableStateOf("ALL") }
    var showExpenseDialog by remember { mutableStateOf(false) }
    var showTransferDialog by remember { mutableStateOf(false) }
    var entryToReverse by remember { mutableStateOf<DailyEntry?>(null) }

    val filteredEntries = remember(entries, selectedFilterType) {
        if (selectedFilterType == "ALL") {
            entries
        } else {
            entries.filter { it.entryType.equals(selectedFilterType, ignoreCase = true) }
        }
    }

    // Daily summary calculations
    val totalCashIn = entries.filter { !it.isReversed }.sumOf { it.cashPart }
    val totalBankIn = entries.filter { !it.isReversed }.sumOf { it.bankPart }
    val totalDueAdded = entries.filter { !it.isReversed }.sumOf { it.duePart }

    Scaffold(
        floatingActionButton = {
            Column(horizontalAlignment = Alignment.End) {
                FloatingActionButton(
                    onClick = { showExpenseDialog = true },
                    containerColor = Color(0xFFBE123C),
                    contentColor = Color.White,
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    Row(modifier = Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ReceiptLong, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Expense / Food", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 14.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Daily Summary Header Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Daily Day Book Summary",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "${entries.size} entries",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Total Cash Flow", fontSize = 11.sp, color = Color.DarkGray)
                            Text(Formatters.formatRupees(totalCashIn), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Column {
                            Text("Total Bank/Online", fontSize = 11.sp, color = Color.DarkGray)
                            Text(Formatters.formatRupees(totalBankIn), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Column {
                            Text("Total Due Created", fontSize = 11.sp, color = Color.DarkGray)
                            Text(Formatters.formatRupees(totalDueAdded), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DenaHaiRed)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action row: Transfer Cash <-> Bank button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Filter Journal",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                OutlinedButton(
                    onClick = { showTransferDialog = true },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.CompareArrows, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Cash ↔ Bank Transfer", fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Filter chips
            val filterOptions = listOf("ALL", "Purchase", "Sale", "Repair", "Expense", "Exchange", "Return")
            ScrollableTabRow(
                selectedTabIndex = filterOptions.indexOf(selectedFilterType).coerceAtLeast(0),
                edgePadding = 0.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                filterOptions.forEach { type ->
                    Tab(
                        selected = selectedFilterType == type,
                        onClick = { selectedFilterType = type },
                        text = { Text(type, fontSize = 12.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (filteredEntries.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "No entries matching filter '$selectedFilterType' for ${currentShop.name}",
                        color = Color.Gray,
                        fontSize = 13.sp
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 90.dp)
                ) {
                    items(filteredEntries) { entry ->
                        Box(modifier = Modifier.fillMaxWidth()) {
                            DailyEntryCard(entry = entry)
                        }
                    }
                }
            }
        }
    }

    // Expense & Food Dialog
    if (showExpenseDialog) {
        AddExpenseDialog(
            onDismiss = { showExpenseDialog = false },
            onAddExpense = { category, amount, mode, desc, person, isFood ->
                viewModel.recordExpense(
                    category = category,
                    amount = amount,
                    paymentMode = mode,
                    description = desc,
                    staffOrPerson = person,
                    isFood = isFood,
                    onSuccess = { showExpenseDialog = false },
                    onError = {}
                )
            }
        )
    }

    // Cash ↔ Bank Transfer Dialog
    if (showTransferDialog) {
        CashBankTransferDialog(
            onDismiss = { showTransferDialog = false },
            onTransfer = { type, amount, ref ->
                viewModel.recordCashBankTransfer(
                    transferType = type,
                    amount = amount,
                    ref = ref,
                    onSuccess = { showTransferDialog = false },
                    onError = {}
                )
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddExpenseDialog(
    onDismiss: () -> Unit,
    onAddExpense: (category: String, amount: Double, mode: String, desc: String, person: String, isFood: Boolean) -> Unit
) {
    var isFood by remember { mutableStateOf(false) }
    var category by remember { mutableStateOf("Shop Expense") }
    var amountText by remember { mutableStateOf("") }
    var paymentMode by remember { mutableStateOf("Cash") }
    var description by remember { mutableStateOf("") }
    var personName by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val categories = if (isFood) {
        listOf("Staff Lunch", "Tea & Snacks", "Dinner", "Water", "Refreshments")
    } else {
        listOf("Electricity Bill", "Shop Rent", "Cleaning / Maintenance", "Stationery", "Internet / Wi-Fi", "Mobile Accessories Purchase", "Other Expense")
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (isFood) "Record Food Expense" else "Record Shop Expense", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !isFood,
                        onClick = {
                            isFood = false
                            category = "Shop Rent"
                        },
                        label = { Text("Shop Expense") }
                    )
                    FilterChip(
                        selected = isFood,
                        onClick = {
                            isFood = true
                            category = "Tea & Snacks"
                        },
                        label = { Text("Food / Meals") }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount (₹)*") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text("Category:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat) },
                                onClick = {
                                    category = cat
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = paymentMode == "Cash",
                        onClick = { paymentMode = "Cash" },
                        label = { Text("Cash") }
                    )
                    FilterChip(
                        selected = paymentMode == "Bank/Online",
                        onClick = { paymentMode = "Bank/Online" },
                        label = { Text("Bank / UPI") }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = personName,
                    onValueChange = { personName = it },
                    label = { Text("Spent by / Paid to") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Notes / Details") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull() ?: 0.0
                    if (amount <= 0) {
                        errorMessage = "Please enter a valid amount"
                        return@Button
                    }
                    onAddExpense(category, amount, paymentMode, description, personName, isFood)
                }
            ) {
                Text("Save Expense")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun CashBankTransferDialog(
    onDismiss: () -> Unit,
    onTransfer: (type: String, amount: Double, ref: String) -> Unit
) {
    var transferType by remember { mutableStateOf("CASH_TO_BANK") }
    var amountText by remember { mutableStateOf("") }
    var referenceText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CompareArrows, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Cash ↔ Bank Transfer", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Internal transfer between Cash in Hand and Bank Account. This does NOT affect profit, loss, or expense.",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = transferType == "CASH_TO_BANK",
                        onClick = { transferType = "CASH_TO_BANK" },
                        label = { Text("Cash -> Bank (Deposit)") }
                    )
                    FilterChip(
                        selected = transferType == "BANK_TO_CASH",
                        onClick = { transferType = "BANK_TO_CASH" },
                        label = { Text("Bank -> Cash (Withdrawal)") }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Transfer Amount (₹)*") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = referenceText,
                    onValueChange = { referenceText = it },
                    label = { Text("Reference / Deposit Slip / Notes") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull() ?: 0.0
                    if (amount <= 0) {
                        errorMessage = "Please enter a valid amount"
                        return@Button
                    }
                    onTransfer(transferType, amount, referenceText)
                }
            ) {
                Text("Execute Transfer")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

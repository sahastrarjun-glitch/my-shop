package com.example.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.DailyEntry
import com.example.ui.components.DueBadge
import com.example.ui.components.Formatters
import com.example.ui.components.SummaryMetricCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.ShopViewModel

@Composable
fun DashboardScreen(
    viewModel: ShopViewModel,
    onNavigateToPurchase: () -> Unit,
    onNavigateToSale: () -> Unit,
    onNavigateToRepair: () -> Unit,
    onNavigateToExchange: () -> Unit,
    onNavigateToReturn: () -> Unit,
    onNavigateToDues: () -> Unit,
    onNavigateToCashBank: () -> Unit,
    onNavigateToStock: () -> Unit,
    onNavigateToDailyEntry: () -> Unit,
    onNavigateToReports: () -> Unit
) {
    val metrics by viewModel.dashboardMetrics.collectAsStateWithLifecycle()
    val currentShop by viewModel.currentShop.collectAsStateWithLifecycle()
    val recentEntries by viewModel.dailyEntries.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Hero Money Available Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(ShopPrimary, Color(0xFF1E40AF), Color(0xFF0D9488))
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "TOTAL MONEY AVAILABLE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFBFDBFE),
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = Formatters.formatRupees(metrics.totalMoneyAvailable),
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                        IconButton(
                            onClick = onNavigateToCashBank,
                            modifier = Modifier
                                .background(Color.White.copy(alpha = 0.2f), CircleShape)
                                .size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = "Cash and Bank",
                                tint = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("💵 Cash in Hand", fontSize = 11.sp, color = Color(0xFFE2E8F0))
                            Text(
                                Formatters.formatRupees(metrics.cashInHand),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color(0xFF86EFAC)
                            )
                        }
                        Column {
                            Text("🏦 Bank / Online", fontSize = 11.sp, color = Color(0xFFE2E8F0))
                            Text(
                                Formatters.formatRupees(metrics.bankBalance),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color(0xFF93C5FD)
                            )
                        }
                        Column {
                            Text("📱 In-Stock Value", fontSize = 11.sp, color = Color(0xFFE2E8F0))
                            Text(
                                Formatters.formatRupees(metrics.currentStockValue),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color(0xFFFDE047)
                            )
                        }
                    }
                }
            }
        }

        // 2. Quick Action Toolbar
        item {
            Text(
                text = "Fast Transactions",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    QuickActionButton(
                        icon = Icons.Default.AddShoppingCart,
                        label = "Purchase",
                        color = Color(0xFF059669),
                        onClick = onNavigateToPurchase
                    )
                }
                item {
                    QuickActionButton(
                        icon = Icons.Default.PointOfSale,
                        label = "Sale",
                        color = Color(0xFF2563EB),
                        onClick = onNavigateToSale
                    )
                }
                item {
                    QuickActionButton(
                        icon = Icons.Default.Build,
                        label = "Repair",
                        color = Color(0xFFD97706),
                        onClick = onNavigateToRepair
                    )
                }
                item {
                    QuickActionButton(
                        icon = Icons.Default.SwapHoriz,
                        label = "Exchange",
                        color = Color(0xFF7C3AED),
                        onClick = onNavigateToExchange
                    )
                }
                item {
                    QuickActionButton(
                        icon = Icons.Default.KeyboardReturn,
                        label = "Return",
                        color = Color(0xFFDC2626),
                        onClick = onNavigateToReturn
                    )
                }
                item {
                    QuickActionButton(
                        icon = Icons.Default.CompareArrows,
                        label = "Cash ↔ Bank",
                        color = Color(0xFF0D9488),
                        onClick = onNavigateToCashBank
                    )
                }
            }
        }

        // 3. Outstanding Dues Banner (Lena Hai & Dena Hai)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Lena Hai (Receivables)
                Card(
                    colors = CardDefaults.cardColors(containerColor = LenaHaiBg),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateToDues() }
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🟢 LENA HAI", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = LenaHaiGreen)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = Formatters.formatRupees(metrics.totalLenaHai),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = LenaHaiGreen
                        )
                        Text("Customer receivable", fontSize = 10.sp, color = Color(0xFF166534))
                    }
                }

                // Dena Hai (Payables)
                Card(
                    colors = CardDefaults.cardColors(containerColor = DenaHaiBg),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateToDues() }
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🔴 DENA HAI", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DenaHaiRed)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = Formatters.formatRupees(metrics.totalDenaHai),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = DenaHaiRed
                        )
                        Text("Seller/Vendor payable", fontSize = 10.sp, color = Color(0xFF991B1B))
                    }
                }
            }
        }

        // 4. Key Metrics Grid
        item {
            Text(
                text = "Today's Overview",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryMetricCard(
                        title = "Current Stock",
                        value = "${metrics.currentStockCount} Mobiles",
                        subtitle = Formatters.formatRupees(metrics.currentStockValue),
                        icon = Icons.Default.PhoneAndroid,
                        accentColor = ShopPrimary,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToStock
                    )
                    SummaryMetricCard(
                        title = "Today's Mobile IN/OUT",
                        value = "IN: ${metrics.todayMobileIn} | OUT: ${metrics.todayMobileOut}",
                        subtitle = "Inventory movements",
                        icon = Icons.Default.SyncAlt,
                        accentColor = ShopSecondary,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryMetricCard(
                        title = "Today's Purchase",
                        value = Formatters.formatRupees(metrics.todayPurchase),
                        icon = Icons.Default.ShoppingBag,
                        accentColor = Color(0xFF047857),
                        modifier = Modifier.weight(1f)
                    )
                    SummaryMetricCard(
                        title = "Today's Sale",
                        value = Formatters.formatRupees(metrics.todaySale),
                        icon = Icons.Default.Sell,
                        accentColor = Color(0xFF1D4ED8),
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryMetricCard(
                        title = "Today's Repair Cost",
                        value = Formatters.formatRupees(metrics.todayRepairCost),
                        icon = Icons.Default.Handyman,
                        accentColor = Color(0xFFB45309),
                        modifier = Modifier.weight(1f)
                    )
                    SummaryMetricCard(
                        title = "Expenses & Food",
                        value = Formatters.formatRupees(metrics.todayExpenses),
                        subtitle = "Staff Adv: ${Formatters.formatRupees(metrics.staffAdvanceTotal)}",
                        icon = Icons.Default.ReceiptLong,
                        accentColor = Color(0xFFBE123C),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 5. Recent Daily Entries Journal
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Daily Entries",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                TextButton(onClick = onNavigateToDailyEntry) {
                    Text("View All", fontSize = 12.sp)
                }
            }
        }

        if (recentEntries.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "No daily entries recorded yet for ${currentShop.name}. Use the Fast Transactions buttons above to add a purchase, sale, repair, or expense.",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        } else {
            items(recentEntries.take(8)) { entry ->
                DailyEntryCard(entry = entry)
            }
        }
    }
}

@Composable
fun QuickActionButton(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.clickable { onClick() }
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = label, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = color)
        }
    }
}

@Composable
fun DailyEntryCard(entry: DailyEntry) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val iconColor = when (entry.entryType) {
                "Purchase" -> Color(0xFF059669)
                "Sale" -> Color(0xFF2563EB)
                "Repair" -> Color(0xFFD97706)
                "Return" -> Color(0xFFDC2626)
                "Exchange" -> Color(0xFF7C3AED)
                "Expense", "Shop Expense", "Food" -> Color(0xFFE11D48)
                else -> Color(0xFF4B5563)
            }

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(36.dp)
                    .background(iconColor.copy(alpha = 0.12f), CircleShape)
            ) {
                Text(
                    text = entry.entryType.take(2).uppercase(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = iconColor
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = entry.description,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${Formatters.formatDate(entry.timestamp)} • ${entry.paymentMode}",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = Formatters.formatRupees(entry.amount),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (entry.entryType in listOf("Sale", "Return")) Color(0xFF15803D) else Color(0xFF1E293B)
                )
                if (entry.duePart > 0) {
                    Text(
                        text = "Due: ${Formatters.formatRupees(entry.duePart)}",
                        fontSize = 10.sp,
                        color = DenaHaiRed,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

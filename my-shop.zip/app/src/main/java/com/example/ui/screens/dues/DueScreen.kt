package com.example.ui.screens.dues

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.DuePayment
import com.example.data.model.DueRecord
import com.example.ui.components.DueBadge
import com.example.ui.components.Formatters
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.ShopViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DueScreen(
    viewModel: ShopViewModel
) {
    val duesList by viewModel.dues.collectAsStateWithLifecycle()
    val currentShop by viewModel.currentShop.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableStateOf("ALL") } // "ALL", "LENA_HAI", "DENA_HAI"
    var statusFilter by remember { mutableStateOf("PENDING_ONLY") } // "PENDING_ONLY", "ALL_STATUS"
    var searchQuery by remember { mutableStateOf("") }

    var selectedDueForPayment by remember { mutableStateOf<DueRecord?>(null) }
    var selectedDueForHistory by remember { mutableStateOf<DueRecord?>(null) }

    val filteredDues = remember(duesList, selectedTab, statusFilter, searchQuery) {
        duesList.filter { due ->
            val matchDirection = when (selectedTab) {
                "LENA_HAI" -> due.dueDirection == "LENA_HAI"
                "DENA_HAI" -> due.dueDirection == "DENA_HAI"
                else -> true
            }
            val matchStatus = if (statusFilter == "PENDING_ONLY") {
                due.status != "CLEARED"
            } else true

            val matchQuery = if (searchQuery.isBlank()) true else {
                val q = searchQuery.trim().lowercase()
                due.personName.lowercase().contains(q) ||
                due.personMobile.lowercase().contains(q) ||
                due.relatedImei.lowercase().contains(q) ||
                due.notes.lowercase().contains(q)
            }

            matchDirection && matchStatus && matchQuery
        }
    }

    val totalLenaHai = duesList
        .filter { it.dueDirection == "LENA_HAI" && it.status != "CLEARED" }
        .sumOf { it.remainingAmount }
    val totalDenaHai = duesList
        .filter { it.dueDirection == "DENA_HAI" && it.status != "CLEARED" }
        .sumOf { it.remainingAmount }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Total Outstanding Summary Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = LenaHaiBg),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("🟢 LENA HAI (Receivable)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LenaHaiGreen)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        Formatters.formatRupees(totalLenaHai),
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = LenaHaiGreen
                    )
                }
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = DenaHaiBg),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("🔴 DENA HAI (Payable)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DenaHaiRed)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        Formatters.formatRupees(totalDenaHai),
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = DenaHaiRed
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search Box
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by person, mobile, IMEI...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = null)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Tabs: All, Lena Hai, Dena Hai
        TabRow(
            selectedTabIndex = when (selectedTab) {
                "LENA_HAI" -> 1
                "DENA_HAI" -> 2
                else -> 0
            }
        ) {
            Tab(selected = selectedTab == "ALL", onClick = { selectedTab = "ALL" }, text = { Text("All Dues") })
            Tab(selected = selectedTab == "LENA_HAI", onClick = { selectedTab = "LENA_HAI" }, text = { Text("Lena Hai") })
            Tab(selected = selectedTab == "DENA_HAI", onClick = { selectedTab = "DENA_HAI" }, text = { Text("Dena Hai") })
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Filter chips: Pending Only vs Cleared Included
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(
                    selected = statusFilter == "PENDING_ONLY",
                    onClick = { statusFilter = "PENDING_ONLY" },
                    label = { Text("Pending / Active Only", fontSize = 11.sp) }
                )
                FilterChip(
                    selected = statusFilter == "ALL_STATUS",
                    onClick = { statusFilter = "ALL_STATUS" },
                    label = { Text("Show Cleared History", fontSize = 11.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        if (filteredDues.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "No dues found for current selection in ${currentShop.name}",
                    fontSize = 13.sp,
                    color = Color.Gray
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                items(filteredDues) { due ->
                    DueRecordCard(
                        due = due,
                        onPayClick = { selectedDueForPayment = due },
                        onHistoryClick = { selectedDueForHistory = due }
                    )
                }
            }
        }
    }

    // Due Payment Dialog
    selectedDueForPayment?.let { due ->
        RecordDuePaymentDialog(
            due = due,
            onDismiss = { selectedDueForPayment = null },
            onSubmit = { cash, bank, ref, notes ->
                viewModel.recordDuePayment(
                    due = due,
                    cashAmount = cash,
                    bankAmount = bank,
                    paymentRef = ref,
                    notes = notes,
                    onSuccess = { selectedDueForPayment = null },
                    onError = {}
                )
            }
        )
    }

    // Due History Dialog
    selectedDueForHistory?.let { due ->
        val payments by viewModel.repository.getDuePayments(due.id).collectAsStateWithLifecycle(emptyList())
        DueHistoryDialog(
            due = due,
            payments = payments,
            onDismiss = { selectedDueForHistory = null }
        )
    }
}

@Composable
fun DueRecordCard(
    due: DueRecord,
    onPayClick: () -> Unit,
    onHistoryClick: () -> Unit
) {
    val isLena = due.dueDirection == "LENA_HAI"

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                DueBadge(direction = due.dueDirection)
                StatusBadge(status = due.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = due.personName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "${due.personRole} ${if (due.personMobile.isNotBlank()) "• ${due.personMobile}" else ""}",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Remaining Due",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                    Text(
                        text = Formatters.formatRupees(due.remainingAmount),
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = if (isLena) LenaHaiGreen else DenaHaiRed
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Details row: Original, Paid, Date
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Original: ${Formatters.formatRupees(due.originalAmount)}", fontSize = 11.sp)
                    Text("Paid: ${Formatters.formatRupees(due.paidAmount)}", fontSize = 11.sp, color = Color(0xFF15803D), fontWeight = FontWeight.SemiBold)
                    Text("Date: ${Formatters.formatDateOnly(due.createdAt)}", fontSize = 11.sp, color = Color.Gray)
                }
            }

            if (due.relatedImei.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Ref: ${due.relatedTransactionType} • IMEI: ${due.relatedImei}",
                    fontSize = 11.sp,
                    color = Color.DarkGray
                )
            }

            if (due.status == "CLEARED") {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Cleared on ${Formatters.formatDateOnly(due.clearedAt ?: due.createdAt)} (Took ${due.durationDays} days)",
                    fontSize = 11.sp,
                    color = Color(0xFF15803D),
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onHistoryClick,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Payment History", fontSize = 12.sp)
                }

                if (due.status != "CLEARED") {
                    Button(
                        onClick = onPayClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isLena) LenaHaiGreen else DenaHaiRed
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isLena) "Receive Payment" else "Pay Udhaar", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun RecordDuePaymentDialog(
    due: DueRecord,
    onDismiss: () -> Unit,
    onSubmit: (cash: Double, bank: Double, ref: String, notes: String) -> Unit
) {
    val isLena = due.dueDirection == "LENA_HAI"
    var cashText by remember { mutableStateOf("") }
    var bankText by remember { mutableStateOf("") }
    var refText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isLena) "Receive Payment from ${due.personName}" else "Make Payment to ${due.personName}",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Total Remaining Due: ${Formatters.formatRupees(due.remainingAmount)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (isLena) LenaHaiGreen else DenaHaiRed
                )
                Text(
                    "Partial payments are supported. Original due date will be preserved.",
                    fontSize = 11.sp,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = cashText,
                    onValueChange = { cashText = it },
                    label = { Text("Cash Amount (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = bankText,
                    onValueChange = { bankText = it },
                    label = { Text("Bank / Online Amount (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = refText,
                    onValueChange = { refText = it },
                    label = { Text("UPI / Bank Ref (if online)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Notes / Remarks") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cash = cashText.toDoubleOrNull() ?: 0.0
                    val bank = bankText.toDoubleOrNull() ?: 0.0
                    val total = cash + bank
                    if (total <= 0) {
                        errorMessage = "Please enter an amount"
                        return@Button
                    }
                    if (total > due.remainingAmount + 0.01) {
                        errorMessage = "Amount cannot exceed remaining due (₹${due.remainingAmount})"
                        return@Button
                    }
                    onSubmit(cash, bank, refText, notesText)
                }
            ) {
                Text("Confirm Payment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun DueHistoryDialog(
    due: DueRecord,
    payments: List<DuePayment>,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Due History", fontWeight = FontWeight.Bold)
                Text(
                    text = "${due.personName} (${due.dueDirection})",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Original Due", fontSize = 10.sp, color = Color.Gray)
                            Text(Formatters.formatRupees(due.originalAmount), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Column {
                            Text("Total Paid", fontSize = 10.sp, color = Color.Gray)
                            Text(Formatters.formatRupees(due.paidAmount), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF15803D))
                        }
                        Column {
                            Text("Remaining", fontSize = 10.sp, color = Color.Gray)
                            Text(Formatters.formatRupees(due.remainingAmount), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DenaHaiRed)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text("Installment Payments (${payments.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))

                if (payments.isEmpty()) {
                    Text("No installment payments made yet.", fontSize = 12.sp, color = Color.Gray)
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(payments) { p ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(1.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(Formatters.formatRupees(p.amount), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF15803D))
                                        Text(Formatters.formatDate(p.timestamp), fontSize = 10.sp, color = Color.Gray)
                                    }
                                    Text("Cash: ₹${p.cashAmount} | Bank: ₹${p.bankAmount} | Left: ₹${p.remainingAfterPayment}", fontSize = 11.sp)
                                    Text("Handled by: ${p.userName}", fontSize = 10.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

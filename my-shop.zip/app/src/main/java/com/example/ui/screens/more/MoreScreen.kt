package com.example.ui.screens.more

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ShopPrimary
import com.example.ui.viewmodel.ShopViewModel

@Composable
fun MoreScreen(
    viewModel: ShopViewModel,
    onNavigateToMovements: () -> Unit,
    onNavigateToCashBank: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToStaff: () -> Unit,
    onNavigateToPurchase: () -> Unit,
    onNavigateToSale: () -> Unit,
    onNavigateToRepair: () -> Unit,
    onNavigateToExchange: () -> Unit,
    onNavigateToReturn: () -> Unit,
    onSwitchUser: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Operations & Registers", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }

        item {
            MoreMenuCard(
                title = "Mobile IN / OUT Registers",
                subtitle = "Complete inward and outward inventory log",
                icon = Icons.Default.SyncAlt,
                color = ShopPrimary,
                onClick = onNavigateToMovements
            )
        }

        item {
            MoreMenuCard(
                title = "Cash & Bank Balance Ledger",
                subtitle = "Opening balance, cash in hand, bank transfers",
                icon = Icons.Default.AccountBalanceWallet,
                color = Color(0xFF0D9488),
                onClick = onNavigateToCashBank
            )
        }

        item {
            MoreMenuCard(
                title = "Reports & Profit / Loss",
                subtitle = "Net profit calculation, sales and stock valuation",
                icon = Icons.Default.Assessment,
                color = Color(0xFF2563EB),
                onClick = onNavigateToReports
            )
        }

        item {
            MoreMenuCard(
                title = "Staff Management",
                subtitle = "Roster, salaries, leaves, and advance tracking",
                icon = Icons.Default.People,
                color = Color(0xFF7C3AED),
                onClick = onNavigateToStaff
            )
        }

        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text("Fast Transactions", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MoreActionTile(
                    title = "Purchase Mobile",
                    icon = Icons.Default.AddShoppingCart,
                    color = Color(0xFF059669),
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToPurchase
                )
                MoreActionTile(
                    title = "Sell Mobile",
                    icon = Icons.Default.PointOfSale,
                    color = Color(0xFF1D4ED8),
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToSale
                )
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MoreActionTile(
                    title = "Repair (Add to IMEI)",
                    icon = Icons.Default.Build,
                    color = Color(0xFFD97706),
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToRepair
                )
                MoreActionTile(
                    title = "Exchange Mobile",
                    icon = Icons.Default.SwapHoriz,
                    color = Color(0xFF7C3AED),
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToExchange
                )
            }
        }

        item {
            MoreActionTile(
                title = "Record Customer / Seller Return",
                icon = Icons.Default.KeyboardReturn,
                color = Color(0xFFDC2626),
                modifier = Modifier.fillMaxWidth(),
                onClick = onNavigateToReturn
            )
        }

        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text("Security & User", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }

        item {
            MoreMenuCard(
                title = "Switch Authorised User",
                subtitle = "Change between Owner and Shop Managers with PIN",
                icon = Icons.Default.Security,
                color = Color(0xFF475569),
                onClick = onSwitchUser
            )
        }
    }
}

@Composable
fun MoreMenuCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = color.copy(alpha = 0.12f),
                shape = RoundedCornerShape(10.dp)
            ) {
                Box(modifier = Modifier.padding(10.dp)) {
                    Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
                }
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(text = subtitle, fontSize = 12.sp, color = Color.Gray)
            }
            Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
        }
    }
}

@Composable
fun MoreActionTile(
    title: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = color)
        }
    }
}

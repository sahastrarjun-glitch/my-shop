package com.example.ui.screens.movements

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.MobileMovement
import com.example.ui.components.Formatters
import com.example.ui.theme.DenaHaiRed
import com.example.ui.theme.LenaHaiGreen
import com.example.ui.viewmodel.ShopViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MovementsScreen(
    viewModel: ShopViewModel
) {
    val movements by viewModel.movements.collectAsStateWithLifecycle()
    val currentShop by viewModel.currentShop.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableStateOf("ALL") } // "ALL", "IN", "OUT"
    var searchQuery by remember { mutableStateOf("") }

    val filteredMovements = remember(movements, selectedTab, searchQuery) {
        movements.filter { mov ->
            val matchDirection = when (selectedTab) {
                "IN" -> mov.direction == "IN"
                "OUT" -> mov.direction == "OUT"
                else -> true
            }
            val matchQuery = if (searchQuery.isBlank()) true else {
                val q = searchQuery.trim().lowercase()
                mov.imei.lowercase().contains(q) ||
                mov.brandModel.lowercase().contains(q) ||
                mov.personName.lowercase().contains(q) ||
                mov.reason.lowercase().contains(q)
            }
            matchDirection && matchQuery
        }
    }

    val inCount = movements.count { it.direction == "IN" }
    val outCount = movements.count { it.direction == "OUT" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Summary Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFDCFCE7)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("📥 TOTAL MOBILE IN", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LenaHaiGreen)
                    Text("$inCount Mobiles", fontWeight = FontWeight.Black, fontSize = 18.sp, color = LenaHaiGreen)
                    Text("Purchases, Returns, Exchanges", fontSize = 10.sp, color = Color.Gray)
                }
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEE2E2)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("📤 TOTAL MOBILE OUT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DenaHaiRed)
                    Text("$outCount Mobiles", fontWeight = FontWeight.Black, fontSize = 18.sp, color = DenaHaiRed)
                    Text("Sales, Returns, Exchanges", fontSize = 10.sp, color = Color.Gray)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by IMEI, brand, person name...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = null)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        TabRow(
            selectedTabIndex = when (selectedTab) {
                "IN" -> 1
                "OUT" -> 2
                else -> 0
            }
        ) {
            Tab(selected = selectedTab == "ALL", onClick = { selectedTab = "ALL" }, text = { Text("All Registers (${movements.size})") })
            Tab(selected = selectedTab == "IN", onClick = { selectedTab = "IN" }, text = { Text("Mobile IN ($inCount)") })
            Tab(selected = selectedTab == "OUT", onClick = { selectedTab = "OUT" }, text = { Text("Mobile OUT ($outCount)") })
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (filteredMovements.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "No movement records found for ${currentShop.name}",
                    fontSize = 13.sp,
                    color = Color.Gray
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                items(filteredMovements) { mov ->
                    MovementItemCard(mov = mov)
                }
            }
        }
    }
}

@Composable
fun MovementItemCard(mov: MobileMovement) {
    val isIn = mov.direction == "IN"
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = if (isIn) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (isIn) "📥 IN" else "📤 OUT",
                            color = if (isIn) LenaHaiGreen else DenaHaiRed,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = mov.brandModel,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Text(
                    text = Formatters.formatRupees(mov.value),
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = if (isIn) Color(0xFF1E293B) else Color(0xFF15803D)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text("IMEI: ${mov.imei}", fontSize = 11.sp, color = Color.DarkGray, fontWeight = FontWeight.Medium)
            Text(
                text = "Reason: ${mov.reason} • Person: ${mov.personName} ${if (mov.personMobile.isNotBlank()) "(${mov.personMobile})" else ""}",
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(2.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = Formatters.formatDate(mov.timestamp),
                    fontSize = 10.sp,
                    color = Color.Gray
                )
                Text(
                    text = "By: ${mov.userName}",
                    fontSize = 10.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

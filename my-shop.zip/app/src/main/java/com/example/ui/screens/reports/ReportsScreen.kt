package com.example.ui.screens.reports

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.Formatters
import com.example.ui.theme.DenaHaiRed
import com.example.ui.theme.LenaHaiGreen
import com.example.ui.theme.ShopPrimary
import com.example.ui.viewmodel.ShopViewModel

@Composable
fun ReportsScreen(
    viewModel: ShopViewModel
) {
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val dailyEntries by viewModel.dailyEntries.collectAsStateWithLifecycle()
    val stock by viewModel.currentStock.collectAsStateWithLifecycle()
    val dues by viewModel.dues.collectAsStateWithLifecycle()
    val currentShop by viewModel.currentShop.collectAsStateWithLifecycle()

    var selectedPeriod by remember { mutableStateOf("ALL_TIME") } // "TODAY", "THIS_MONTH", "ALL_TIME"

    val totalMobilesSold = sales.size
    val grossSaleAmount = sales.sumOf { it.salePrice }
    val totalCostOfSoldMobiles = sales.sumOf { it.totalCost }
    val grossProfitFromSales = sales.sumOf { it.profitOrLoss }

    // Expenses (Shop + Food)
    val totalExpenses = dailyEntries
        .filter { (it.entryType == "Expense" || it.entryType == "Shop Expense" || it.entryType == "Food") && !it.isReversed }
        .sumOf { it.amount }

    // Net Profit = Gross Profit - All Expenses (Repairs are already in mobile cost; do not double count!)
    val netProfit = grossProfitFromSales - totalExpenses

    // Stock Valuation at Total Cost
    val inStockCount = stock.size
    val inStockValuation = stock.sumOf { it.totalCost }

    // Top brands in stock
    val brandCounts = stock.groupingBy { it.brand }.eachCount()
        .toList()
        .sortedByDescending { it.second }
        .take(5)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Hero Net Profit Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = Brush.horizontalGradient(
                            if (netProfit >= 0) listOf(Color(0xFF065F46), Color(0xFF047857), Color(0xFF0D9488))
                            else listOf(Color(0xFF991B1B), Color(0xFFB91C1C), Color(0xFFDC2626))
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "REAL NET PROFIT / LOSS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.8f),
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = (if (netProfit >= 0) "+ " else "") + Formatters.formatRupees(netProfit),
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Net Profit = Gross Profit (${Formatters.formatRupees(grossProfitFromSales)}) - Expenses (${Formatters.formatRupees(totalExpenses)})",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }
            }
        }

        // P&L Breakdown Card
        item {
            Text("Profit & Loss Breakdown", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ReportRow(label = "Total Mobiles Sold", value = "$totalMobilesSold Units")
                    ReportRow(label = "Gross Sales Revenue", value = Formatters.formatRupees(grossSaleAmount), isBold = true)
                    ReportRow(label = "Less: Total Cost of Sold Mobiles", value = "- " + Formatters.formatRupees(totalCostOfSoldMobiles), color = Color.Gray)
                    HorizontalDivider()
                    ReportRow(
                        label = "Gross Profit from Sales",
                        value = Formatters.formatRupees(grossProfitFromSales),
                        isBold = true,
                        color = if (grossProfitFromSales >= 0) LenaHaiGreen else DenaHaiRed
                    )
                    ReportRow(label = "Less: Shop & Food Expenses", value = "- " + Formatters.formatRupees(totalExpenses), color = DenaHaiRed)
                    HorizontalDivider()
                    ReportRow(
                        label = "Final Net Profit",
                        value = Formatters.formatRupees(netProfit),
                        isBold = true,
                        color = if (netProfit >= 0) LenaHaiGreen else DenaHaiRed
                    )
                }
            }
        }

        // Inventory Stock Valuation
        item {
            Text("Stock Valuation & Assets", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Current In-Stock", fontSize = 11.sp, color = Color.Gray)
                        Text("$inStockCount Mobiles", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Total Stock Value", fontSize = 11.sp, color = Color.Gray)
                        Text(
                            Formatters.formatRupees(inStockValuation),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = ShopPrimary
                        )
                    }
                }
            }
        }

        // Top Brands in Stock
        item {
            Text("Top Mobile Brands in Stock", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (brandCounts.isEmpty()) {
                        Text("No stock available to show brand distribution", fontSize = 12.sp, color = Color.Gray)
                    } else {
                        brandCounts.forEach { (brand, count) ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(brand, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("$count Mobiles", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = ShopPrimary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportRow(
    label: String,
    value: String,
    isBold: Boolean = false,
    color: Color = Color.Unspecified
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = if (isBold) FontWeight.Black else FontWeight.Medium,
            color = if (color != Color.Unspecified) color else MaterialTheme.colorScheme.onSurface
        )
    }
}

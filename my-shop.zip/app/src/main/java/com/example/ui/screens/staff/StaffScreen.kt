package com.example.ui.screens.staff

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.StaffAdvance
import com.example.data.model.StaffEntity
import com.example.data.model.StaffLeave
import com.example.ui.components.Formatters
import com.example.ui.theme.DenaHaiRed
import com.example.ui.theme.LenaHaiGreen
import com.example.ui.theme.ShopPrimary
import com.example.ui.viewmodel.ShopViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StaffScreen(
    viewModel: ShopViewModel
) {
    val staffList by viewModel.staff.collectAsStateWithLifecycle()
    val advances by viewModel.staffAdvances.collectAsStateWithLifecycle()
    val leaves by viewModel.staffLeaves.collectAsStateWithLifecycle()
    val currentShop by viewModel.currentShop.collectAsStateWithLifecycle()

    var showAddStaffDialog by remember { mutableStateOf(false) }
    var selectedStaffForAdvance by remember { mutableStateOf<StaffEntity?>(null) }
    var selectedStaffForLeave by remember { mutableStateOf<StaffEntity?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddStaffDialog = true },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Row(modifier = Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Staff", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 14.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Total Advance Outstanding
            val totalOutstandingAdvance = advances.sumOf { it.remainingAdvance }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Active Staff Members: ${staffList.size}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Shop: ${currentShop.name}", fontSize = 11.sp, color = Color.Gray)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Total Advances Out", fontSize = 10.sp, color = Color.Gray)
                        Text(
                            Formatters.formatRupees(totalOutstandingAdvance),
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = DenaHaiRed
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text("Staff Roster", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))

            if (staffList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No staff members registered for ${currentShop.name}. Tap Add Staff to create one.", color = Color.Gray, fontSize = 13.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(staffList) { st ->
                        val staffAdv = advances.filter { it.staffId == st.id }.sumOf { it.remainingAdvance }
                        StaffCard(
                            staff = st,
                            advanceRemaining = staffAdv,
                            onGiveAdvance = { selectedStaffForAdvance = st },
                            onRecordLeave = { selectedStaffForLeave = st }
                        )
                    }
                }
            }
        }
    }

    if (showAddStaffDialog) {
        AddStaffDialog(
            onDismiss = { showAddStaffDialog = false },
            onAdd = { name, mobile, salary, notes ->
                viewModel.addStaff(name, mobile, salary, notes) {
                    showAddStaffDialog = false
                }
            }
        )
    }

    selectedStaffForAdvance?.let { st ->
        StaffAdvanceDialog(
            staff = st,
            onDismiss = { selectedStaffForAdvance = null },
            onSubmit = { amount, mode, purpose ->
                viewModel.recordStaffAdvance(st, amount, mode, purpose, onSuccess = {
                    selectedStaffForAdvance = null
                }, onError = {})
            }
        )
    }

    selectedStaffForLeave?.let { st ->
        StaffLeaveDialog(
            staff = st,
            onDismiss = { selectedStaffForLeave = null },
            onSubmit = { days, reason, isPaid ->
                viewModel.recordStaffLeave(st, days, reason, isPaid) {
                    selectedStaffForLeave = null
                }
            }
        )
    }
}

@Composable
fun StaffCard(
    staff: StaffEntity,
    advanceRemaining: Double,
    onGiveAdvance: () -> Unit,
    onRecordLeave: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(staff.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(staff.mobile, fontSize = 12.sp, color = Color.Gray)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Monthly Salary", fontSize = 10.sp, color = Color.Gray)
                    Text(Formatters.formatRupees(staff.salary), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Advance Balance: ${Formatters.formatRupees(advanceRemaining)}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = if (advanceRemaining > 0) DenaHaiRed else Color.Black)
                    Text("Status: Active", fontSize = 11.sp, color = LenaHaiGreen, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onRecordLeave,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.EventBusy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Record Leave", fontSize = 11.sp)
                }

                Button(
                    onClick = onGiveAdvance,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.MonetizationOn, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Give Advance", fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun AddStaffDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, mobile: String, salary: Double, notes: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var salaryText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add New Staff Member", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name*") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = mobile,
                    onValueChange = { mobile = it },
                    label = { Text("Mobile Number") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = salaryText,
                    onValueChange = { salaryText = it },
                    label = { Text("Monthly Salary (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Designation / Notes") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val sal = salaryText.toDoubleOrNull() ?: 0.0
                        onAdd(name, mobile, sal, notes)
                    }
                }
            ) { Text("Save Staff") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun StaffAdvanceDialog(
    staff: StaffEntity,
    onDismiss: () -> Unit,
    onSubmit: (amount: Double, mode: String, purpose: String) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var paymentMode by remember { mutableStateOf("Cash") }
    var purpose by remember { mutableStateOf("Personal Advance") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Give Advance to ${staff.name}", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Advance Amount (₹)*") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = paymentMode == "Cash", onClick = { paymentMode = "Cash" }, label = { Text("Cash") })
                    FilterChip(selected = paymentMode == "Bank", onClick = { paymentMode = "Bank" }, label = { Text("Bank / UPI") })
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = purpose,
                    onValueChange = { purpose = it },
                    label = { Text("Reason / Purpose") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    if (amt > 0) {
                        onSubmit(amt, paymentMode, purpose)
                    }
                }
            ) { Text("Confirm Advance") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun StaffLeaveDialog(
    staff: StaffEntity,
    onDismiss: () -> Unit,
    onSubmit: (days: Int, reason: String, isPaid: Boolean) -> Unit
) {
    var daysText by remember { mutableStateOf("1") }
    var reason by remember { mutableStateOf("") }
    var isPaid by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Leave for ${staff.name}", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = daysText,
                    onValueChange = { daysText = it },
                    label = { Text("Number of Days") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("Reason for Leave") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isPaid, onCheckedChange = { isPaid = it })
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Paid Leave")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val d = daysText.toIntOrNull() ?: 1
                    onSubmit(d, reason, isPaid)
                }
            ) { Text("Record Leave") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

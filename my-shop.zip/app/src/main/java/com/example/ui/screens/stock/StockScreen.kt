package com.example.ui.screens.stock

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.MobileItem
import com.example.ui.components.Formatters
import com.example.ui.components.ImeiTimelineDialog
import com.example.ui.components.StatusBadge
import com.example.ui.theme.DenaHaiRed
import com.example.ui.theme.ShopPrimary
import com.example.ui.viewmodel.ShopViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StockScreen(
    viewModel: ShopViewModel,
    onNavigateToPurchase: () -> Unit
) {
    val stockList by viewModel.currentStock.collectAsStateWithLifecycle()
    val allMobilesList by viewModel.allMobiles.collectAsStateWithLifecycle()
    val currentShop by viewModel.currentShop.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("IN_STOCK_ONLY") } // "IN_STOCK_ONLY" or "ALL_HISTORY"

    var selectedMobileForHistory by remember { mutableStateOf<MobileItem?>(null) }
    val coroutineScope = rememberCoroutineScope()

    val sourceList = if (selectedFilter == "IN_STOCK_ONLY") stockList else allMobilesList

    val filteredList = remember(sourceList, searchQuery) {
        if (searchQuery.isBlank()) {
            sourceList
        } else {
            val q = searchQuery.trim().lowercase()
            sourceList.filter {
                it.imei1.lowercase().contains(q) ||
                it.imei2.lowercase().contains(q) ||
                it.brand.lowercase().contains(q) ||
                it.model.lowercase().contains(q) ||
                it.sellerName.lowercase().contains(q) ||
                it.sellerMobile.lowercase().contains(q) ||
                it.notes.lowercase().contains(q)
            }
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNavigateToPurchase,
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Row(modifier = Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Add, contentDescription = "Add Mobile")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Buy / Add Mobile", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 14.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search by IMEI, brand, model, seller, phone...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Filter Chips (Current Available Stock vs All Registered Mobiles)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = selectedFilter == "IN_STOCK_ONLY",
                    onClick = { selectedFilter = "IN_STOCK_ONLY" },
                    label = { Text("Current Stock (${stockList.size})") },
                    leadingIcon = {
                        if (selectedFilter == "IN_STOCK_ONLY") {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }
                )
                FilterChip(
                    selected = selectedFilter == "ALL_HISTORY",
                    onClick = { selectedFilter = "ALL_HISTORY" },
                    label = { Text("All Mobiles (${allMobilesList.size})") },
                    leadingIcon = {
                        if (selectedFilter == "ALL_HISTORY") {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Stock Count & Total Cost Summary banner
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${filteredList.size} mobiles found in ${currentShop.name}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Total: " + Formatters.formatRupees(filteredList.sumOf { it.totalCost }),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (filteredList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.PhoneAndroid,
                            contentDescription = null,
                            tint = Color.Gray,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (searchQuery.isNotBlank()) "No mobiles matching '$searchQuery'" else "No mobiles in stock for ${currentShop.name}",
                            fontSize = 14.sp,
                            color = Color.Gray
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredList) { mobile ->
                        MobileStockCard(
                            mobile = mobile,
                            onClick = { selectedMobileForHistory = mobile },
                            onMarkRepairComplete = {
                                viewModel.completeRepair(mobile)
                            }
                        )
                    }
                }
            }
        }
    }

    // IMEI Timeline Modal Dialog
    selectedMobileForHistory?.let { mob ->
        val movements by viewModel.repository.getTimelineForImei(mob.imei1).collectAsStateWithLifecycle(emptyList())
        val repairs by viewModel.repository.getRepairsForImei(mob.imei1).collectAsStateWithLifecycle(emptyList())

        ImeiTimelineDialog(
            mobile = mob,
            movements = movements,
            repairs = repairs,
            onDismiss = { selectedMobileForHistory = null }
        )
    }
}

@Composable
fun MobileStockCard(
    mobile: MobileItem,
    onClick: () -> Unit,
    onMarkRepairComplete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${mobile.brand} ${mobile.model}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "${if (mobile.ram.isNotBlank()) "${mobile.ram} RAM / " else ""}${mobile.storage} • ${mobile.color} • ${mobile.condition}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                StatusBadge(status = mobile.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // IMEI details
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("IMEI: ${mobile.imei1}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    if (mobile.imei2.isNotBlank()) {
                        Text("IMEI 2: ${mobile.imei2}", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Financial breakdown: Purchase Price + Repair Cost = Total Cost
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Purchase Price", fontSize = 11.sp, color = Color.Gray)
                    Text(Formatters.formatRupees(mobile.purchasePrice), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Column {
                    Text("Repair Cost", fontSize = 11.sp, color = Color.Gray)
                    Text(
                        Formatters.formatRupees(mobile.totalRepairCost),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = if (mobile.totalRepairCost > 0) DenaHaiRed else Color.Black
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Total Cost", fontSize = 11.sp, color = Color.Gray)
                    Text(
                        Formatters.formatRupees(mobile.totalCost),
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            if (mobile.status == "REPAIRING") {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onMarkRepairComplete,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Mark Repair Completed (Return to Stock)", fontSize = 12.sp)
                }
            }
        }
    }
}

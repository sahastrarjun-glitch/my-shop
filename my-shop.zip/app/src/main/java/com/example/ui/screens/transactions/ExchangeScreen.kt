package com.example.ui.screens.transactions

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.MobileItem
import com.example.ui.components.Formatters
import com.example.ui.theme.DenaHaiRed
import com.example.ui.theme.LenaHaiGreen
import com.example.ui.viewmodel.ShopViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExchangeScreen(
    viewModel: ShopViewModel,
    onNavigateBack: () -> Unit
) {
    val stockList by viewModel.currentStock.collectAsStateWithLifecycle()
    var selectedOutgoingMobile by remember { mutableStateOf<MobileItem?>(null) }
    var showOutgoingPicker by remember { mutableStateOf(false) }

    var customerName by remember { mutableStateOf("") }
    var customerMobile by remember { mutableStateOf("") }

    // Outgoing Mobile Valuation
    var outgoingValueText by remember { mutableStateOf("") }

    // Incoming Mobile
    var incomingImei by remember { mutableStateOf("") }
    var incomingBrand by remember { mutableStateOf("") }
    var incomingModel by remember { mutableStateOf("") }
    var incomingRam by remember { mutableStateOf("6 GB") }
    var incomingStorage by remember { mutableStateOf("128 GB") }
    var incomingCondition by remember { mutableStateOf("Good") }
    var incomingValueText by remember { mutableStateOf("") }

    // Settlement
    var customerPaidCashText by remember { mutableStateOf("") }
    var customerPaidBankText by remember { mutableStateOf("") }
    var shopPaidCashText by remember { mutableStateOf("") }
    var shopPaidBankText by remember { mutableStateOf("") }
    var dueAmountText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    val outgoingValue = outgoingValueText.toDoubleOrNull() ?: 0.0
    val incomingValue = incomingValueText.toDoubleOrNull() ?: 0.0
    val diff = outgoingValue - incomingValue // If positive, outgoing is worth more -> customer pays shop.

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Exchange (Mobile for Mobile)") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Exchange records Outgoing Mobile OUT of stock, Incoming Mobile IN stock with new IMEI, and settles money difference automatically.",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Text("1. Outgoing Mobile (From Shop Stock)", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            if (selectedOutgoingMobile == null) {
                OutlinedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showOutgoingPicker = true },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Select Outgoing Mobile from Shop Stock", fontWeight = FontWeight.SemiBold)
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                    }
                }
            } else {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${selectedOutgoingMobile!!.brand} ${selectedOutgoingMobile!!.model}", fontWeight = FontWeight.Bold)
                            TextButton(onClick = { showOutgoingPicker = true }) { Text("Change", fontSize = 12.sp) }
                        }
                        Text("IMEI: ${selectedOutgoingMobile!!.imei1} • Total Cost: ${Formatters.formatRupees(selectedOutgoingMobile!!.totalCost)}", fontSize = 12.sp)
                    }
                }
            }

            OutlinedTextField(
                value = outgoingValueText,
                onValueChange = { outgoingValueText = it },
                label = { Text("Valuation of Outgoing Mobile (₹)*") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            HorizontalDivider()

            Text("2. Incoming Mobile (From Customer)", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            OutlinedTextField(
                value = incomingImei,
                onValueChange = { incomingImei = it },
                label = { Text("Incoming Mobile IMEI 1*") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = incomingBrand,
                    onValueChange = { incomingBrand = it },
                    label = { Text("Brand*") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = incomingModel,
                    onValueChange = { incomingModel = it },
                    label = { Text("Model*") },
                    modifier = Modifier.weight(1f)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = incomingStorage,
                    onValueChange = { incomingStorage = it },
                    label = { Text("Storage") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = incomingCondition,
                    onValueChange = { incomingCondition = it },
                    label = { Text("Condition") },
                    modifier = Modifier.weight(1f)
                )
            }

            OutlinedTextField(
                value = incomingValueText,
                onValueChange = { incomingValueText = it },
                label = { Text("Valuation of Incoming Mobile (₹)*") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            HorizontalDivider()

            Text("3. Customer & Settlement Difference", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            OutlinedTextField(
                value = customerName,
                onValueChange = { customerName = it },
                label = { Text("Customer Name*") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = customerMobile,
                onValueChange = { customerMobile = it },
                label = { Text("Customer Mobile Number") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth()
            )

            // Valuation Difference Banner
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Valuation Difference:", fontSize = 12.sp, color = Color.Gray)
                    Text(
                        text = if (diff > 0) {
                            "Customer must pay Shop: ${Formatters.formatRupees(diff)}"
                        } else if (diff < 0) {
                            "Shop must pay Customer: ${Formatters.formatRupees(-diff)}"
                        } else "Exact Equal Exchange (₹0 Difference)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = if (diff >= 0) LenaHaiGreen else DenaHaiRed
                    )
                }
            }

            if (diff > 0) {
                Text("Customer pays Shop:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = customerPaidCashText,
                        onValueChange = { customerPaidCashText = it },
                        label = { Text("Cash Received") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = customerPaidBankText,
                        onValueChange = { customerPaidBankText = it },
                        label = { Text("Bank Received") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
            } else if (diff < 0) {
                Text("Shop pays Customer:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = shopPaidCashText,
                        onValueChange = { shopPaidCashText = it },
                        label = { Text("Cash Paid") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = shopPaidBankText,
                        onValueChange = { shopPaidBankText = it },
                        label = { Text("Bank Paid") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            OutlinedTextField(
                value = dueAmountText,
                onValueChange = { dueAmountText = it },
                label = { Text("Any Remaining Due / Udhaar (₹)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Exchange Notes") },
                modifier = Modifier.fillMaxWidth()
            )

            if (errorMessage != null) {
                Text(errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    val outMobile = selectedOutgoingMobile
                    if (outMobile == null) {
                        errorMessage = "Please select outgoing mobile from stock"
                        return@Button
                    }
                    if (incomingImei.isBlank() || incomingBrand.isBlank() || incomingModel.isBlank()) {
                        errorMessage = "Please fill in incoming mobile IMEI, brand and model"
                        return@Button
                    }
                    if (customerName.isBlank()) {
                        errorMessage = "Please enter customer name"
                        return@Button
                    }

                    isSaving = true
                    viewModel.recordExchange(
                        customerName = customerName,
                        customerMobile = customerMobile,
                        incomingImei = incomingImei,
                        incomingBrand = incomingBrand,
                        incomingModel = incomingModel,
                        incomingRam = incomingRam,
                        incomingStorage = incomingStorage,
                        incomingCondition = incomingCondition,
                        incomingValue = incomingValue,
                        outgoingMobile = outMobile,
                        outgoingValue = outgoingValue,
                        differenceAmount = diff,
                        customerPaidCash = customerPaidCashText.toDoubleOrNull() ?: 0.0,
                        customerPaidBank = customerPaidBankText.toDoubleOrNull() ?: 0.0,
                        shopPaidCash = shopPaidCashText.toDoubleOrNull() ?: 0.0,
                        shopPaidBank = shopPaidBankText.toDoubleOrNull() ?: 0.0,
                        dueAmount = dueAmountText.toDoubleOrNull() ?: 0.0,
                        notes = notes,
                        onSuccess = {
                            isSaving = false
                            onNavigateBack()
                        },
                        onError = { err ->
                            isSaving = false
                            errorMessage = err
                        }
                    )
                },
                enabled = !isSaving,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(if (isSaving) "Recording Exchange..." else "Record Exchange & Update Both Mobiles", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showOutgoingPicker) {
        AlertDialog(
            onDismissRequest = { showOutgoingPicker = false },
            title = { Text("Select Outgoing Mobile from Stock", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 350.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    stockList.forEach { mob ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedOutgoingMobile = mob
                                    if (outgoingValueText.isEmpty()) {
                                        outgoingValueText = mob.totalCost.toString()
                                    }
                                    showOutgoingPicker = false
                                }
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("${mob.brand} ${mob.model}", fontWeight = FontWeight.Bold)
                                Text("IMEI: ${mob.imei1} • Total Cost: ${Formatters.formatRupees(mob.totalCost)}", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showOutgoingPicker = false }) { Text("Cancel") }
            }
        )
    }
}

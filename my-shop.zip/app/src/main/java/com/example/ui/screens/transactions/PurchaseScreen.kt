package com.example.ui.screens.transactions

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.Formatters
import com.example.ui.viewmodel.ShopViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PurchaseScreen(
    viewModel: ShopViewModel,
    onNavigateBack: () -> Unit
) {
    var imei1 by remember { mutableStateOf("") }
    var imei2 by remember { mutableStateOf("") }
    var brand by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var ram by remember { mutableStateOf("6 GB") }
    var storage by remember { mutableStateOf("128 GB") }
    var color by remember { mutableStateOf("") }
    var condition by remember { mutableStateOf("Good") }
    var purchasePriceText by remember { mutableStateOf("") }

    // Seller fields
    var sellerName by remember { mutableStateOf("") }
    var sellerMobile by remember { mutableStateOf("") }
    var sellerAadhaar by remember { mutableStateOf("") }
    var sellerAddress by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    // Payment split
    var cashPaidText by remember { mutableStateOf("") }
    var bankPaidText by remember { mutableStateOf("") }
    var dueAmountText by remember { mutableStateOf("") }
    var paymentRef by remember { mutableStateOf("") }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    val purchasePrice = purchasePriceText.toDoubleOrNull() ?: 0.0
    val cashPaid = cashPaidText.toDoubleOrNull() ?: 0.0
    val bankPaid = bankPaidText.toDoubleOrNull() ?: 0.0
    val dueAmount = dueAmountText.toDoubleOrNull() ?: 0.0
    val totalPaid = cashPaid + bankPaid + dueAmount

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Purchase Mobile (Inward)") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Core rule notice card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Enter once → Automatically updates Stock, Mobile IN Register, Cash/Bank Balances, Due Ledgers, and Daily Journal.",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Text("Mobile Specifications", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            OutlinedTextField(
                value = imei1,
                onValueChange = { imei1 = it },
                label = { Text("IMEI 1 (Required)*") },
                leadingIcon = { Icon(Icons.Default.PhoneAndroid, contentDescription = null) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = imei2,
                onValueChange = { imei2 = it },
                label = { Text("IMEI 2 (Optional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = brand,
                    onValueChange = { brand = it },
                    label = { Text("Brand (e.g. Apple, Samsung)*") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = model,
                    onValueChange = { model = it },
                    label = { Text("Model (e.g. iPhone 13)*") },
                    modifier = Modifier.weight(1f)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = ram,
                    onValueChange = { ram = it },
                    label = { Text("RAM") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = storage,
                    onValueChange = { storage = it },
                    label = { Text("Storage") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = color,
                    onValueChange = { color = it },
                    label = { Text("Color") },
                    modifier = Modifier.weight(1f)
                )
            }

            Text("Condition:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            val conditions = listOf("Like New", "Good", "Fair", "Needs Repair")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                conditions.forEach { cond ->
                    FilterChip(
                        selected = condition == cond,
                        onClick = { condition = cond },
                        label = { Text(cond, fontSize = 11.sp) }
                    )
                }
            }

            HorizontalDivider()

            Text("Seller Details & Verification", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            OutlinedTextField(
                value = sellerName,
                onValueChange = { sellerName = it },
                label = { Text("Seller Name*") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = sellerMobile,
                onValueChange = { sellerMobile = it },
                label = { Text("Seller Phone Number") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = sellerAadhaar,
                onValueChange = { sellerAadhaar = it },
                label = { Text("Seller Aadhaar Number (Masked securely)") },
                supportingText = { Text("Aadhaar will be masked as XXXX-XXXX-#### for privacy & security") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = sellerAddress,
                onValueChange = { sellerAddress = it },
                label = { Text("Seller Address / Location") },
                modifier = Modifier.fillMaxWidth()
            )

            HorizontalDivider()

            Text("Financial Settlement", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            OutlinedTextField(
                value = purchasePriceText,
                onValueChange = {
                    purchasePriceText = it
                    // Auto-fill cashPaid if empty
                    if (cashPaidText.isEmpty() && bankPaidText.isEmpty() && dueAmountText.isEmpty()) {
                        cashPaidText = it
                    }
                },
                label = { Text("Total Purchase Price (₹)*") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            Text("Payment Split (Must sum to ${Formatters.formatRupees(purchasePrice)}):", fontSize = 12.sp, color = Color.Gray)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = cashPaidText,
                    onValueChange = { cashPaidText = it },
                    label = { Text("💵 Cash Paid") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = bankPaidText,
                    onValueChange = { bankPaidText = it },
                    label = { Text("🏦 Bank / Online") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }

            OutlinedTextField(
                value = dueAmountText,
                onValueChange = { dueAmountText = it },
                label = { Text("🔴 Due Payable to Seller (DENA HAI)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            if (bankPaid > 0) {
                OutlinedTextField(
                    value = paymentRef,
                    onValueChange = { paymentRef = it },
                    label = { Text("Bank / UPI Reference ID") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Purchase Notes / Accessories included") },
                modifier = Modifier.fillMaxWidth()
            )

            // Balance Check Indicator
            val difference = purchasePrice - totalPaid
            Surface(
                color = if (Math.abs(difference) < 0.01) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (Math.abs(difference) < 0.01) "✓ Payment split matches purchase price" else "⚠️ Difference: ₹$difference",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = if (Math.abs(difference) < 0.01) Color(0xFF15803D) else Color(0xFFB91C1C)
                    )
                    Text("Total: ${Formatters.formatRupees(totalPaid)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (errorMessage != null) {
                Text(errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    if (imei1.isBlank() || brand.isBlank() || model.isBlank() || sellerName.isBlank()) {
                        errorMessage = "Please fill in IMEI, Brand, Model, and Seller Name"
                        return@Button
                    }
                    if (purchasePrice <= 0) {
                        errorMessage = "Please enter a valid purchase price"
                        return@Button
                    }
                    if (Math.abs(purchasePrice - totalPaid) > 1.0) {
                        errorMessage = "Payment split (Cash: ₹$cashPaid + Bank: ₹$bankPaid + Due: ₹$dueAmount) must equal Purchase Price (₹$purchasePrice)"
                        return@Button
                    }

                    isSaving = true
                    viewModel.recordPurchase(
                        imei1 = imei1,
                        imei2 = imei2,
                        brand = brand,
                        model = model,
                        ram = ram,
                        storage = storage,
                        color = color,
                        condition = condition,
                        purchasePrice = purchasePrice,
                        sellerName = sellerName,
                        sellerMobile = sellerMobile,
                        sellerAadhaar = sellerAadhaar,
                        sellerAddress = sellerAddress,
                        notes = notes,
                        cashPaid = cashPaid,
                        bankPaid = bankPaid,
                        dueAmount = dueAmount,
                        paymentRef = paymentRef,
                        onSuccess = {
                            isSaving = false
                            onNavigateBack()
                        },
                        onError = { err ->
                            isSaving = false
                            errorMessage = err
                        }
                    )
                },
                enabled = !isSaving,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(if (isSaving) "Saving Purchase..." else "Record Purchase & Update All", fontWeight = FontWeight.Bold)
            }
        }
    }
}

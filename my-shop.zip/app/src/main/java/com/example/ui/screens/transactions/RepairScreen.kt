package com.example.ui.screens.transactions

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.MobileItem
import com.example.ui.components.Formatters
import com.example.ui.theme.DenaHaiRed
import com.example.ui.viewmodel.ShopViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RepairScreen(
    viewModel: ShopViewModel,
    onNavigateBack: () -> Unit
) {
    val stockList by viewModel.currentStock.collectAsStateWithLifecycle()
    var selectedMobile by remember { mutableStateOf<MobileItem?>(null) }
    var showMobilePicker by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    var repairDetails by remember { mutableStateOf("") }
    var technicianOrVendor by remember { mutableStateOf("") }
    var costText by remember { mutableStateOf("") }
    var markAsCompleted by remember { mutableStateOf(true) }
    var notes by remember { mutableStateOf("") }

    // Payment split
    var cashPaidText by remember { mutableStateOf("") }
    var bankPaidText by remember { mutableStateOf("") }
    var dueAmountText by remember { mutableStateOf("") }
    var paymentRef by remember { mutableStateOf("") }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    val cost = costText.toDoubleOrNull() ?: 0.0
    val cashPaid = cashPaidText.toDoubleOrNull() ?: 0.0
    val bankPaid = bankPaidText.toDoubleOrNull() ?: 0.0
    val dueAmount = dueAmountText.toDoubleOrNull() ?: 0.0
    val totalPaid = cashPaid + bankPaid + dueAmount

    val currentTotalCost = selectedMobile?.totalCost ?: 0.0
    val newTotalCost = currentTotalCost + cost

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Record Repair (Linked to IMEI)") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Build, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Repair cost automatically increases the Mobile's Total Cost and updates Cash/Bank and Daily Entries.",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Text("Select Mobile to Repair", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            if (selectedMobile == null) {
                OutlinedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showMobilePicker = true },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Choose Mobile by IMEI or Model", fontWeight = FontWeight.SemiBold)
                            Text("${stockList.size} mobiles available in stock", fontSize = 12.sp, color = Color.Gray)
                        }
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                    }
                }
            } else {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${selectedMobile!!.brand} ${selectedMobile!!.model}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            TextButton(onClick = { showMobilePicker = true }) {
                                Text("Change", fontSize = 12.sp)
                            }
                        }
                        Text("IMEI 1: ${selectedMobile!!.imei1}", fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Current Total Cost: ${Formatters.formatRupees(currentTotalCost)}", fontSize = 12.sp)
                            Text(
                                "After Repair: ${Formatters.formatRupees(newTotalCost)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            HorizontalDivider()

            Text("Repair Information", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            OutlinedTextField(
                value = repairDetails,
                onValueChange = { repairDetails = it },
                label = { Text("Repair Details (e.g. Display Combo, Battery, IC)*") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = technicianOrVendor,
                onValueChange = { technicianOrVendor = it },
                label = { Text("Technician / Vendor Name") },
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Checkbox(
                    checked = markAsCompleted,
                    onCheckedChange = { markAsCompleted = it }
                )
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text("Repair Completed", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(
                        if (markAsCompleted) "Mobile stays IN STOCK ready for sale" else "Mobile status will be set to REPAIRING",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }

            HorizontalDivider()

            Text("Repair Cost & Payment Split", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            OutlinedTextField(
                value = costText,
                onValueChange = {
                    costText = it
                    if (cashPaidText.isEmpty() && bankPaidText.isEmpty() && dueAmountText.isEmpty()) {
                        cashPaidText = it
                    }
                },
                label = { Text("Total Repair Cost (₹)*") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = cashPaidText,
                    onValueChange = { cashPaidText = it },
                    label = { Text("💵 Cash Paid") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = bankPaidText,
                    onValueChange = { bankPaidText = it },
                    label = { Text("🏦 Bank / Online") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }

            OutlinedTextField(
                value = dueAmountText,
                onValueChange = { dueAmountText = it },
                label = { Text("🔴 Repair Due Payable to Vendor (DENA HAI)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            if (bankPaid > 0) {
                OutlinedTextField(
                    value = paymentRef,
                    onValueChange = { paymentRef = it },
                    label = { Text("Bank / UPI Reference ID") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Repair Warranty / Notes") },
                modifier = Modifier.fillMaxWidth()
            )

            val difference = cost - totalPaid
            Surface(
                color = if (Math.abs(difference) < 0.01) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (Math.abs(difference) < 0.01) "✓ Payment split matches repair cost" else "⚠️ Difference: ₹$difference",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = if (Math.abs(difference) < 0.01) Color(0xFF15803D) else Color(0xFFB91C1C)
                    )
                    Text("Total: ${Formatters.formatRupees(totalPaid)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (errorMessage != null) {
                Text(errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    val mobile = selectedMobile
                    if (mobile == null) {
                        errorMessage = "Please select a mobile"
                        return@Button
                    }
                    if (repairDetails.isBlank()) {
                        errorMessage = "Please enter repair details"
                        return@Button
                    }
                    if (cost <= 0) {
                        errorMessage = "Please enter repair cost"
                        return@Button
                    }
                    if (Math.abs(cost - totalPaid) > 1.0) {
                        errorMessage = "Payment split must equal Repair Cost (₹$cost)"
                        return@Button
                    }

                    isSaving = true
                    viewModel.recordRepair(
                        mobile = mobile,
                        repairDetails = repairDetails,
                        technicianOrVendor = technicianOrVendor,
                        cost = cost,
                        cashPaid = cashPaid,
                        bankPaid = bankPaid,
                        dueAmount = dueAmount,
                        paymentRef = paymentRef,
                        markAsCompleted = markAsCompleted,
                        notes = notes,
                        onSuccess = {
                            isSaving = false
                            onNavigateBack()
                        },
                        onError = { err ->
                            isSaving = false
                            errorMessage = err
                        }
                    )
                },
                enabled = !isSaving,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(if (isSaving) "Saving Repair..." else "Record Repair & Update Total Cost", fontWeight = FontWeight.Bold)
            }
        }
    }

    // Mobile Picker Dialog
    if (showMobilePicker) {
        AlertDialog(
            onDismissRequest = { showMobilePicker = false },
            title = { Text("Select Mobile for Repair", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search brand, model, IMEI...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val filtered = stockList.filter {
                        if (searchQuery.isBlank()) true else {
                            val q = searchQuery.trim().lowercase()
                            it.brand.lowercase().contains(q) ||
                            it.model.lowercase().contains(q) ||
                            it.imei1.lowercase().contains(q)
                        }
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 350.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        filtered.forEach { mob ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedMobile = mob
                                        showMobilePicker = false
                                    }
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text("${mob.brand} ${mob.model}", fontWeight = FontWeight.Bold)
                                    Text("IMEI: ${mob.imei1} • Cost: ${Formatters.formatRupees(mob.totalCost)}", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showMobilePicker = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

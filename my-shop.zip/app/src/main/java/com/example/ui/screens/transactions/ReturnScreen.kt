package com.example.ui.screens.transactions

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardReturn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.ShopViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReturnScreen(
    viewModel: ShopViewModel,
    onNavigateBack: () -> Unit
) {
    var returnType by remember { mutableStateOf("CUSTOMER_RETURN") } // "CUSTOMER_RETURN" or "SHOP_TO_SELLER"
    var imei by remember { mutableStateOf("") }
    var brandModel by remember { mutableStateOf("") }
    var personName by remember { mutableStateOf("") }
    var personMobile by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }

    var refundAmountText by remember { mutableStateOf("") }
    var cashAmountText by remember { mutableStateOf("") }
    var bankAmountText by remember { mutableStateOf("") }
    var dueAmountText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    val refundAmount = refundAmountText.toDoubleOrNull() ?: 0.0

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Record Return") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.KeyboardReturn, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Customer Return puts mobile back into stock and pays refund. Shop Return to Seller removes mobile from stock and recovers money.",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Text("Return Type", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = returnType == "CUSTOMER_RETURN",
                    onClick = { returnType = "CUSTOMER_RETURN" },
                    label = { Text("1. Customer Return (Inward)") }
                )
                FilterChip(
                    selected = returnType == "SHOP_TO_SELLER",
                    onClick = { returnType = "SHOP_TO_SELLER" },
                    label = { Text("2. Return to Seller (Outward)") }
                )
            }

            HorizontalDivider()

            Text("Mobile & Person Information", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            OutlinedTextField(
                value = imei,
                onValueChange = { imei = it },
                label = { Text("Mobile IMEI*") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = brandModel,
                onValueChange = { brandModel = it },
                label = { Text("Brand & Model (e.g. Vivo V20)*") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = personName,
                onValueChange = { personName = it },
                label = { Text(if (returnType == "CUSTOMER_RETURN") "Customer Name*" else "Seller Name*") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = personMobile,
                onValueChange = { personMobile = it },
                label = { Text("Contact Phone Number") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = reason,
                onValueChange = { reason = it },
                label = { Text("Reason for Return (e.g. Mic issue, display flickering)*") },
                modifier = Modifier.fillMaxWidth()
            )

            HorizontalDivider()

            Text("Refund Settlement", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            OutlinedTextField(
                value = refundAmountText,
                onValueChange = {
                    refundAmountText = it
                    if (cashAmountText.isEmpty() && bankAmountText.isEmpty() && dueAmountText.isEmpty()) {
                        cashAmountText = it
                    }
                },
                label = { Text("Total Refund Amount (₹)*") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = cashAmountText,
                    onValueChange = { cashAmountText = it },
                    label = { Text("Cash Part") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = bankAmountText,
                    onValueChange = { bankAmountText = it },
                    label = { Text("Bank / Online Part") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }

            OutlinedTextField(
                value = dueAmountText,
                onValueChange = { dueAmountText = it },
                label = { Text("Due Part (if any)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes / Remarks") },
                modifier = Modifier.fillMaxWidth()
            )

            if (errorMessage != null) {
                Text(errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    if (imei.isBlank() || personName.isBlank() || reason.isBlank()) {
                        errorMessage = "Please fill in IMEI, person name and reason"
                        return@Button
                    }
                    if (refundAmount <= 0) {
                        errorMessage = "Please enter valid refund amount"
                        return@Button
                    }

                    isSaving = true
                    viewModel.recordReturn(
                        returnType = returnType,
                        imei = imei,
                        brandModel = brandModel,
                        personName = personName,
                        personMobile = personMobile,
                        reason = reason,
                        refundAmount = refundAmount,
                        cashAmount = cashAmountText.toDoubleOrNull() ?: 0.0,
                        bankAmount = bankAmountText.toDoubleOrNull() ?: 0.0,
                        dueAmount = dueAmountText.toDoubleOrNull() ?: 0.0,
                        notes = notes,
                        onSuccess = {
                            isSaving = false
                            onNavigateBack()
                        },
                        onError = { err ->
                            isSaving = false
                            errorMessage = err
                        }
                    )
                },
                enabled = !isSaving,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(if (isSaving) "Recording Return..." else "Record Return & Update Stock", fontWeight = FontWeight.Bold)
            }
        }
    }
}

package com.example.ui.screens.transactions

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.MobileItem
import com.example.ui.components.Formatters
import com.example.ui.theme.DenaHaiRed
import com.example.ui.theme.LenaHaiGreen
import com.example.ui.viewmodel.ShopViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SaleScreen(
    viewModel: ShopViewModel,
    onNavigateBack: () -> Unit
) {
    val stockList by viewModel.currentStock.collectAsStateWithLifecycle()
    var selectedMobile by remember { mutableStateOf<MobileItem?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var showMobilePicker by remember { mutableStateOf(false) }

    // Customer fields
    var customerName by remember { mutableStateOf("") }
    var customerMobile by remember { mutableStateOf("") }
    var customerAddress by remember { mutableStateOf("") }

    // Financials
    var salePriceText by remember { mutableStateOf("") }
    var cashPaidText by remember { mutableStateOf("") }
    var bankPaidText by remember { mutableStateOf("") }
    var dueAmountText by remember { mutableStateOf("") }
    var paymentRef by remember { mutableStateOf("") }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    val salePrice = salePriceText.toDoubleOrNull() ?: 0.0
    val cashPaid = cashPaidText.toDoubleOrNull() ?: 0.0
    val bankPaid = bankPaidText.toDoubleOrNull() ?: 0.0
    val dueAmount = dueAmountText.toDoubleOrNull() ?: 0.0
    val totalPaid = cashPaid + bankPaid + dueAmount

    val totalCost = selectedMobile?.totalCost ?: 0.0
    val profitOrLoss = if (salePrice > 0) salePrice - totalCost else 0.0

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Sale Mobile (Outward)") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Core rule notice card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Enter once → Automatically updates Stock to SOLD, registers Mobile OUT, adds Cash/Bank, records Due (if any), and tracks Profit/Loss.",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Text("Select Mobile from Stock", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            if (selectedMobile == null) {
                OutlinedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showMobilePicker = true },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Choose Mobile from Shop Stock", fontWeight = FontWeight.SemiBold)
                            Text("${stockList.size} available in stock", fontSize = 12.sp, color = Color.Gray)
                        }
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                    }
                }
            } else {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${selectedMobile!!.brand} ${selectedMobile!!.model}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            TextButton(onClick = { showMobilePicker = true }) {
                                Text("Change", fontSize = 12.sp)
                            }
                        }
                        Text("IMEI 1: ${selectedMobile!!.imei1} • Storage: ${selectedMobile!!.storage} • Condition: ${selectedMobile!!.condition}", fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Purchase: ${Formatters.formatRupees(selectedMobile!!.purchasePrice)}", fontSize = 11.sp)
                            Text("Repair Cost: ${Formatters.formatRupees(selectedMobile!!.totalRepairCost)}", fontSize = 11.sp)
                            Text(
                                "Total Cost: ${Formatters.formatRupees(selectedMobile!!.totalCost)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            HorizontalDivider()

            Text("Customer Details", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            OutlinedTextField(
                value = customerName,
                onValueChange = { customerName = it },
                label = { Text("Customer Name*") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = customerMobile,
                onValueChange = { customerMobile = it },
                label = { Text("Customer Phone Number") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = customerAddress,
                onValueChange = { customerAddress = it },
                label = { Text("Customer Address / City") },
                modifier = Modifier.fillMaxWidth()
            )

            HorizontalDivider()

            Text("Sale Financials & Settlement", fontWeight = FontWeight.Bold, fontSize = 15.sp)

            OutlinedTextField(
                value = salePriceText,
                onValueChange = {
                    salePriceText = it
                    if (cashPaidText.isEmpty() && bankPaidText.isEmpty() && dueAmountText.isEmpty()) {
                        cashPaidText = it
                    }
                },
                label = { Text("Sale Price (₹)*") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            // Real-Time Profit / Loss Live Indicator
            if (selectedMobile != null && salePrice > 0) {
                Surface(
                    color = if (profitOrLoss >= 0) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (profitOrLoss >= 0) "✓ Estimated Profit on this Mobile" else "⚠️ Loss on this Mobile",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (profitOrLoss >= 0) LenaHaiGreen else DenaHaiRed
                            )
                            Text(
                                text = "Sale Price (${Formatters.formatRupees(salePrice)}) - Total Cost (${Formatters.formatRupees(totalCost)})",
                                fontSize = 10.sp,
                                color = Color.DarkGray
                            )
                        }
                        Text(
                            text = (if (profitOrLoss >= 0) "+ " else "") + Formatters.formatRupees(profitOrLoss),
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = if (profitOrLoss >= 0) LenaHaiGreen else DenaHaiRed
                        )
                    }
                }
            }

            Text("Payment Received Split (Must sum to ${Formatters.formatRupees(salePrice)}):", fontSize = 12.sp, color = Color.Gray)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = cashPaidText,
                    onValueChange = { cashPaidText = it },
                    label = { Text("💵 Cash Received") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = bankPaidText,
                    onValueChange = { bankPaidText = it },
                    label = { Text("🏦 Bank / Online") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }

            OutlinedTextField(
                value = dueAmountText,
                onValueChange = { dueAmountText = it },
                label = { Text("🟢 Customer Due / Udhaar (LENA HAI)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            if (bankPaid > 0) {
                OutlinedTextField(
                    value = paymentRef,
                    onValueChange = { paymentRef = it },
                    label = { Text("Bank / UPI Reference ID") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Difference check
            val difference = salePrice - totalPaid
            Surface(
                color = if (Math.abs(difference) < 0.01) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (Math.abs(difference) < 0.01) "✓ Payment split matches sale price" else "⚠️ Difference: ₹$difference",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = if (Math.abs(difference) < 0.01) Color(0xFF15803D) else Color(0xFFB91C1C)
                    )
                    Text("Total Received: ${Formatters.formatRupees(totalPaid)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (errorMessage != null) {
                Text(errorMessage!!, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    val mobile = selectedMobile
                    if (mobile == null) {
                        errorMessage = "Please select a mobile to sell"
                        return@Button
                    }
                    if (customerName.isBlank()) {
                        errorMessage = "Please enter customer name"
                        return@Button
                    }
                    if (salePrice <= 0) {
                        errorMessage = "Please enter a valid sale price"
                        return@Button
                    }
                    if (Math.abs(salePrice - totalPaid) > 1.0) {
                        errorMessage = "Payment split (Cash: ₹$cashPaid + Bank: ₹$bankPaid + Due: ₹$dueAmount) must equal Sale Price (₹$salePrice)"
                        return@Button
                    }

                    isSaving = true
                    viewModel.recordSale(
                        mobile = mobile,
                        customerName = customerName,
                        customerMobile = customerMobile,
                        customerAddress = customerAddress,
                        salePrice = salePrice,
                        cashPaid = cashPaid,
                        bankPaid = bankPaid,
                        dueAmount = dueAmount,
                        paymentRef = paymentRef,
                        onSuccess = {
                            isSaving = false
                            onNavigateBack()
                        },
                        onError = { err ->
                            isSaving = false
                            errorMessage = err
                        }
                    )
                },
                enabled = !isSaving,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(if (isSaving) "Recording Sale..." else "Complete Sale & Update All", fontWeight = FontWeight.Bold)
            }
        }
    }

    // Mobile Picker Dialog
    if (showMobilePicker) {
        AlertDialog(
            onDismissRequest = { showMobilePicker = false },
            title = { Text("Select In-Stock Mobile", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search brand, model, IMEI...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val filtered = stockList.filter {
                        if (searchQuery.isBlank()) true else {
                            val q = searchQuery.trim().lowercase()
                            it.brand.lowercase().contains(q) ||
                            it.model.lowercase().contains(q) ||
                            it.imei1.lowercase().contains(q)
                        }
                    }

                    if (filtered.isEmpty()) {
                        Text("No matching mobiles in stock", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(12.dp))
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 350.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            filtered.forEach { mob ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedMobile = mob
                                            showMobilePicker = false
                                        }
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("${mob.brand} ${mob.model}", fontWeight = FontWeight.Bold)
                                        Text("IMEI: ${mob.imei1} • ${mob.storage} • ${mob.condition}", fontSize = 11.sp, color = Color.Gray)
                                        Text("Total Cost: ${Formatters.formatRupees(mob.totalCost)}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showMobilePicker = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

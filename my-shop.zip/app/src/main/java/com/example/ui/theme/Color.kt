package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ShopPrimary = Color(0xFF1E3A8A)
val ShopPrimaryContainer = Color(0xFFDBEAFE)
val ShopOnPrimary = Color(0xFFFFFFFF)
val ShopSecondary = Color(0xFF0D9488)
val ShopSecondaryContainer = Color(0xFFCCFBF1)
val ShopTertiary = Color(0xFFD97706)
val ShopBackground = Color(0xFFF8FAFC)
val ShopSurface = Color(0xFFFFFFFF)
val ShopSurfaceVariant = Color(0xFFF1F5F9)
val ShopOutline = Color(0xFFCBD5E1)

// Financial Semantic Colors
val LenaHaiGreen = Color(0xFF15803D)
val LenaHaiBg = Color(0xFFDCFCE7)
val DenaHaiRed = Color(0xFFDC2626)
val DenaHaiBg = Color(0xFFFEE2E2)
val CashColor = Color(0xFF047857)
val BankColor = Color(0xFF4338CA)
val ProfitColor = Color(0xFF16A34A)
val LossColor = Color(0xFFE11D48)

// Dark Theme Colors
val DarkPrimary = Color(0xFF93C5FD)
val DarkPrimaryContainer = Color(0xFF1E40AF)
val DarkSecondary = Color(0xFF5EEAD4)
val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)


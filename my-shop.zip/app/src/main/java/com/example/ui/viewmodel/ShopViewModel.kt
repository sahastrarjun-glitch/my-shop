package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.AuthRepository
import com.example.data.repository.ShopRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

data class DashboardMetrics(
    val currentStockCount: Int = 0,
    val currentStockValue: Double = 0.0,
    val todayMobileIn: Int = 0,
    val todayMobileOut: Int = 0,
    val todayPurchase: Double = 0.0,
    val todaySale: Double = 0.0,
    val todayRepairCost: Double = 0.0,
    val todayExpenses: Double = 0.0,
    val cashInHand: Double = 0.0,
    val bankBalance: Double = 0.0,
    val totalMoneyAvailable: Double = 0.0,
    val totalLenaHai: Double = 0.0,
    val totalDenaHai: Double = 0.0,
    val staffAdvanceTotal: Double = 0.0
)

@OptIn(ExperimentalCoroutinesApi::class)
class ShopViewModel(
    val repository: ShopRepository,
    val authRepository: AuthRepository
) : ViewModel() {

    val currentUser = authRepository.currentUser
    val selectedShopId = authRepository.selectedShopId
    val isAuthenticated = authRepository.isAuthenticated

    val allShops = repository.getShops().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val allUsers = repository.getUsers().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // Current selected shop object
    val currentShop = combine(allShops, selectedShopId) { shops, id ->
        shops.firstOrNull { it.id == id } ?: Shop(
            id = id,
            name = if (id == "shop_1") "Shop 1 - Main Branch" else "Shop 2 - City Market",
            address = "",
            phone = ""
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        Shop("shop_1", "Shop 1 - Main Branch", "", "")
    )

    // Shop-specific reactive data streams
    val currentStock = selectedShopId.flatMapLatest { shopId ->
        repository.getCurrentStock(shopId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allMobiles = selectedShopId.flatMapLatest { shopId ->
        repository.getAllMobiles(shopId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val movements = selectedShopId.flatMapLatest { shopId ->
        repository.getMovementsForShop(shopId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dailyEntries = selectedShopId.flatMapLatest { shopId ->
        repository.getDailyEntries(shopId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cashBankTransactions = selectedShopId.flatMapLatest { shopId ->
        repository.getCashBankTransactions(shopId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sales = selectedShopId.flatMapLatest { shopId ->
        repository.getSales(shopId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val repairs = selectedShopId.flatMapLatest { shopId ->
        repository.getRepairs(shopId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dues = selectedShopId.flatMapLatest { shopId ->
        repository.getAllDues(shopId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val staff = selectedShopId.flatMapLatest { shopId ->
        repository.getStaff(shopId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val staffAdvances = selectedShopId.flatMapLatest { shopId ->
        repository.getStaffAdvances(shopId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val staffLeaves = selectedShopId.flatMapLatest { shopId ->
        repository.getStaffLeaves(shopId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs = selectedShopId.flatMapLatest { shopId ->
        repository.getAuditLogs(shopId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Calculated Dashboard Metrics
    val dashboardMetrics: StateFlow<DashboardMetrics> = combine(
        currentShop,
        currentStock,
        movements,
        dailyEntries,
        cashBankTransactions,
        dues,
        staffAdvances
    ) { args: Array<Any> ->
        val shop = args[0] as Shop
        @Suppress("UNCHECKED_CAST")
        val stock = args[1] as List<MobileItem>
        @Suppress("UNCHECKED_CAST")
        val movs = args[2] as List<MobileMovement>
        @Suppress("UNCHECKED_CAST")
        val entries = args[3] as List<DailyEntry>
        @Suppress("UNCHECKED_CAST")
        val cashBank = args[4] as List<CashBankTransaction>
        @Suppress("UNCHECKED_CAST")
        val dueList = args[5] as List<DueRecord>
        @Suppress("UNCHECKED_CAST")
        val advances = args[6] as List<StaffAdvance>

        val startOfToday = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        // Stock stats
        val stockCount = stock.size
        val stockValue = stock.sumOf { it.totalCost }

        // Today's Movements
        val todayIn = movs.count { it.direction == "IN" && it.timestamp >= startOfToday }
        val todayOut = movs.count { it.direction == "OUT" && it.timestamp >= startOfToday }

        // Today's Purchase & Sale
        val todayPurchases = entries
            .filter { it.entryType == "Purchase" && it.timestamp >= startOfToday && !it.isReversed }
            .sumOf { it.amount }
        val todaySales = entries
            .filter { it.entryType == "Sale" && it.timestamp >= startOfToday && !it.isReversed }
            .sumOf { it.amount }

        // Today's Repair & Expenses
        val todayRepairs = entries
            .filter { it.entryType == "Repair" && it.timestamp >= startOfToday && !it.isReversed }
            .sumOf { it.amount }
        val todayExp = entries
            .filter { (it.entryType == "Expense" || it.entryType == "Shop Expense" || it.entryType == "Food") && it.timestamp >= startOfToday && !it.isReversed }
            .sumOf { it.amount }

        // Cash & Bank Balances
        val cashIn = cashBank.filter { it.type == "CASH_IN" }.sumOf { it.amount }
        val cashOut = cashBank.filter { it.type == "CASH_OUT" }.sumOf { it.amount }
        val cashBalance = shop.openingCash + cashIn - cashOut

        val bankIn = cashBank.filter { it.type == "BANK_IN" }.sumOf { it.amount }
        val bankOut = cashBank.filter { it.type == "BANK_OUT" }.sumOf { it.amount }
        val bankBalance = shop.openingBank + bankIn - bankOut

        val totalMoney = cashBalance + bankBalance

        // Dues
        val activeLenaHai = dueList
            .filter { it.dueDirection == "LENA_HAI" && it.status != "CLEARED" }
            .sumOf { it.remainingAmount }
        val activeDenaHai = dueList
            .filter { it.dueDirection == "DENA_HAI" && it.status != "CLEARED" }
            .sumOf { it.remainingAmount }

        // Staff Advance
        val totalAdvance = advances.sumOf { it.remainingAdvance }

        DashboardMetrics(
            currentStockCount = stockCount,
            currentStockValue = stockValue,
            todayMobileIn = todayIn,
            todayMobileOut = todayOut,
            todayPurchase = todayPurchases,
            todaySale = todaySales,
            todayRepairCost = todayRepairs,
            todayExpenses = todayExp,
            cashInHand = cashBalance,
            bankBalance = bankBalance,
            totalMoneyAvailable = totalMoney,
            totalLenaHai = activeLenaHai,
            totalDenaHai = activeDenaHai,
            staffAdvanceTotal = totalAdvance
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardMetrics())

    // Actions
    fun switchShop(shopId: String) {
        authRepository.selectShop(shopId)
    }

    fun switchUser(user: User) {
        authRepository.switchUserDirectly(user)
    }

    suspend fun verifyPin(userId: String, pin: String): Boolean {
        return authRepository.loginWithPin(userId, pin)
    }

    fun recordPurchase(
        imei1: String,
        imei2: String,
        brand: String,
        model: String,
        ram: String,
        storage: String,
        color: String,
        condition: String,
        purchasePrice: Double,
        sellerName: String,
        sellerMobile: String,
        sellerAadhaar: String,
        sellerAddress: String,
        notes: String,
        cashPaid: Double,
        bankPaid: Double,
        dueAmount: Double,
        paymentRef: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                if (imei1.isBlank()) {
                    onError("IMEI 1 is required")
                    return@launch
                }
                if (repository.checkDuplicateImei(imei1.trim())) {
                    onError("Warning: IMEI '$imei1' already exists in the system!")
                    return@launch
                }
                val totalPay = cashPaid + bankPaid + dueAmount
                if (Math.abs(totalPay - purchasePrice) > 1.0) {
                    onError("Payment split (Cash: ₹$cashPaid + Bank: ₹$bankPaid + Due: ₹$dueAmount = ₹$totalPay) must equal Purchase Price (₹$purchasePrice)")
                    return@launch
                }

                repository.recordPurchase(
                    shopId = selectedShopId.value,
                    imei1 = imei1,
                    imei2 = imei2,
                    brand = brand,
                    model = model,
                    ram = ram,
                    storage = storage,
                    color = color,
                    condition = condition,
                    purchasePrice = purchasePrice,
                    sellerName = sellerName,
                    sellerMobile = sellerMobile,
                    sellerAadhaar = sellerAadhaar,
                    sellerAddress = sellerAddress,
                    notes = notes,
                    cashPaid = cashPaid,
                    bankPaid = bankPaid,
                    dueAmount = dueAmount,
                    paymentRef = paymentRef,
                    user = currentUser.value
                )
                onSuccess()
            } catch (e: Exception) {
                onError(e.localizedMessage ?: "Failed to record purchase")
            }
        }
    }

    fun recordSale(
        mobile: MobileItem,
        customerName: String,
        customerMobile: String,
        customerAddress: String,
        salePrice: Double,
        cashPaid: Double,
        bankPaid: Double,
        dueAmount: Double,
        paymentRef: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                if (customerName.isBlank()) {
                    onError("Customer name is required")
                    return@launch
                }
                val totalPay = cashPaid + bankPaid + dueAmount
                if (Math.abs(totalPay - salePrice) > 1.0) {
                    onError("Payment split (Cash: ₹$cashPaid + Bank: ₹$bankPaid + Due: ₹$dueAmount = ₹$totalPay) must equal Sale Price (₹$salePrice)")
                    return@launch
                }

                repository.recordSale(
                    mobile = mobile,
                    customerName = customerName,
                    customerMobile = customerMobile,
                    customerAddress = customerAddress,
                    salePrice = salePrice,
                    cashPaid = cashPaid,
                    bankPaid = bankPaid,
                    dueAmount = dueAmount,
                    paymentRef = paymentRef,
                    user = currentUser.value
                )
                onSuccess()
            } catch (e: Exception) {
                onError(e.localizedMessage ?: "Failed to record sale")
            }
        }
    }

    fun recordRepair(
        mobile: MobileItem,
        repairDetails: String,
        technicianOrVendor: String,
        cost: Double,
        cashPaid: Double,
        bankPaid: Double,
        dueAmount: Double,
        paymentRef: String,
        markAsCompleted: Boolean,
        notes: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                if (repairDetails.isBlank()) {
                    onError("Repair details are required")
                    return@launch
                }
                val totalPay = cashPaid + bankPaid + dueAmount
                if (Math.abs(totalPay - cost) > 1.0) {
                    onError("Payment split must equal Repair Cost (₹$cost)")
                    return@launch
                }

                repository.recordRepair(
                    mobile = mobile,
                    repairDetails = repairDetails,
                    technicianOrVendor = technicianOrVendor,
                    cost = cost,
                    cashPaid = cashPaid,
                    bankPaid = bankPaid,
                    dueAmount = dueAmount,
                    paymentRef = paymentRef,
                    markAsCompleted = markAsCompleted,
                    notes = notes,
                    user = currentUser.value
                )
                onSuccess()
            } catch (e: Exception) {
                onError(e.localizedMessage ?: "Failed to record repair")
            }
        }
    }

    fun completeRepair(mobile: MobileItem) {
        viewModelScope.launch {
            repository.completeRepair(mobile, currentUser.value)
        }
    }

    fun recordReturn(
        returnType: String,
        imei: String,
        brandModel: String,
        personName: String,
        personMobile: String,
        reason: String,
        refundAmount: Double,
        cashAmount: Double,
        bankAmount: Double,
        dueAmount: Double,
        notes: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                if (imei.isBlank() || personName.isBlank()) {
                    onError("IMEI and Person Name are required")
                    return@launch
                }
                repository.recordReturn(
                    shopId = selectedShopId.value,
                    returnType = returnType,
                    imei = imei,
                    brandModel = brandModel,
                    personName = personName,
                    personMobile = personMobile,
                    reason = reason,
                    refundAmount = refundAmount,
                    cashAmount = cashAmount,
                    bankAmount = bankAmount,
                    dueAmount = dueAmount,
                    notes = notes,
                    user = currentUser.value
                )
                onSuccess()
            } catch (e: Exception) {
                onError(e.localizedMessage ?: "Failed to record return")
            }
        }
    }

    fun recordExchange(
        customerName: String,
        customerMobile: String,
        incomingImei: String,
        incomingBrand: String,
        incomingModel: String,
        incomingRam: String,
        incomingStorage: String,
        incomingCondition: String,
        incomingValue: Double,
        outgoingMobile: MobileItem,
        outgoingValue: Double,
        differenceAmount: Double,
        customerPaidCash: Double,
        customerPaidBank: Double,
        shopPaidCash: Double,
        shopPaidBank: Double,
        dueAmount: Double,
        notes: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                if (incomingImei.isBlank()) {
                    onError("Incoming IMEI is required")
                    return@launch
                }
                if (repository.checkDuplicateImei(incomingImei.trim())) {
                    onError("Incoming IMEI '$incomingImei' already exists in the system!")
                    return@launch
                }

                repository.recordExchange(
                    shopId = selectedShopId.value,
                    customerName = customerName,
                    customerMobile = customerMobile,
                    incomingImei = incomingImei,
                    incomingBrand = incomingBrand,
                    incomingModel = incomingModel,
                    incomingRam = incomingRam,
                    incomingStorage = incomingStorage,
                    incomingCondition = incomingCondition,
                    incomingValue = incomingValue,
                    outgoingMobile = outgoingMobile,
                    outgoingValue = outgoingValue,
                    differenceAmount = differenceAmount,
                    customerPaidCash = customerPaidCash,
                    customerPaidBank = customerPaidBank,
                    shopPaidCash = shopPaidCash,
                    shopPaidBank = shopPaidBank,
                    dueAmount = dueAmount,
                    notes = notes,
                    user = currentUser.value
                )
                onSuccess()
            } catch (e: Exception) {
                onError(e.localizedMessage ?: "Failed to record exchange")
            }
        }
    }

    fun recordDuePayment(
        due: DueRecord,
        cashAmount: Double,
        bankAmount: Double,
        paymentRef: String,
        notes: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val totalPayment = cashAmount + bankAmount
                if (totalPayment <= 0) {
                    onError("Payment amount must be greater than 0")
                    return@launch
                }
                if (totalPayment > due.remainingAmount + 0.01) {
                    onError("Payment (₹$totalPayment) cannot exceed remaining due amount (₹${due.remainingAmount})")
                    return@launch
                }

                repository.recordDuePayment(
                    due = due,
                    cashAmount = cashAmount,
                    bankAmount = bankAmount,
                    paymentRef = paymentRef,
                    notes = notes,
                    user = currentUser.value
                )
                onSuccess()
            } catch (e: Exception) {
                onError(e.localizedMessage ?: "Failed to record due payment")
            }
        }
    }

    fun recordCashBankTransfer(
        transferType: String,
        amount: Double,
        ref: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                if (amount <= 0) {
                    onError("Transfer amount must be greater than 0")
                    return@launch
                }
                repository.recordCashBankTransfer(
                    shopId = selectedShopId.value,
                    transferType = transferType,
                    amount = amount,
                    referenceOrNotes = ref,
                    user = currentUser.value
                )
                onSuccess()
            } catch (e: Exception) {
                onError(e.localizedMessage ?: "Failed to transfer money")
            }
        }
    }

    fun recordExpense(
        category: String,
        amount: Double,
        paymentMode: String,
        description: String,
        staffOrPerson: String,
        isFood: Boolean,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                if (amount <= 0) {
                    onError("Expense amount must be greater than 0")
                    return@launch
                }
                repository.recordExpense(
                    shopId = selectedShopId.value,
                    category = category,
                    amount = amount,
                    paymentMode = paymentMode,
                    description = description,
                    staffOrPerson = staffOrPerson,
                    isFood = isFood,
                    user = currentUser.value
                )
                onSuccess()
            } catch (e: Exception) {
                onError(e.localizedMessage ?: "Failed to record expense")
            }
        }
    }

    fun recordStaffAdvance(
        staff: StaffEntity,
        amount: Double,
        paymentMode: String,
        purpose: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                if (amount <= 0) {
                    onError("Advance amount must be greater than 0")
                    return@launch
                }
                repository.recordStaffAdvance(
                    staffId = staff.id,
                    staffName = staff.name,
                    shopId = selectedShopId.value,
                    amount = amount,
                    paymentMode = paymentMode,
                    purpose = purpose,
                    user = currentUser.value
                )
                onSuccess()
            } catch (e: Exception) {
                onError(e.localizedMessage ?: "Failed to record staff advance")
            }
        }
    }

    fun recordStaffLeave(
        staff: StaffEntity,
        days: Int,
        reason: String,
        isPaid: Boolean,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.recordStaffLeave(
                staffId = staff.id,
                staffName = staff.name,
                shopId = selectedShopId.value,
                days = days,
                reason = reason,
                isPaid = isPaid,
                user = currentUser.value
            )
            onSuccess()
        }
    }

    fun addStaff(name: String, mobile: String, salary: Double, notes: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.addStaff(
                StaffEntity(
                    shopId = selectedShopId.value,
                    name = name.trim(),
                    mobile = mobile.trim(),
                    salary = salary,
                    notes = notes.trim()
                )
            )
            onSuccess()
        }
    }

    fun updateOpeningBalances(cash: Double, bank: Double, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.updateOpeningBalances(selectedShopId.value, cash, bank, currentUser.value)
            onSuccess()
        }
    }

    fun reverseDailyEntry(entry: DailyEntry, reason: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.reverseDailyEntry(entry, reason, currentUser.value)
            onSuccess()
        }
    }
}

package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.model.User
import com.example.data.repository.ShopRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var database: AppDatabase
    private lateinit var repository: ShopRepository
    private val testUser = User(
        id = "user_1",
        name = "Owner Admin",
        pin = "1111",
        role = "ADMIN",
        assignedShopId = null
    )

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = ShopRepository(database)
    }

    @After
    fun teardown() {
        database.close()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("MY SHOP", appName)
    }

    @Test
    fun `single entry purchase automatically updates stock, movement in, cash ledger, and daily entry`() = runBlocking {
        // Record purchase
        val mobileId = repository.recordPurchase(
            shopId = "shop_1",
            imei1 = "869123456789012",
            imei2 = "",
            brand = "Apple",
            model = "iPhone 13",
            ram = "6 GB",
            storage = "128 GB",
            color = "Midnight",
            condition = "Good",
            purchasePrice = 30000.0,
            sellerName = "Rahul Verma",
            sellerMobile = "9876543210",
            sellerAadhaar = "123456789012",
            sellerAddress = "Sector 18, Noida",
            notes = "With original box",
            cashPaid = 20000.0,
            bankPaid = 10000.0,
            dueAmount = 0.0,
            paymentRef = "UPI12345",
            user = testUser
        )

        val mobile = repository.getMobileById(mobileId)
        assertNotNull(mobile)

        // 1. Stock check
        val inStock = repository.getCurrentStock("shop_1").first()
        assertEquals(1, inStock.size)
        assertEquals("869123456789012", inStock[0].imei1)
        assertEquals("IN_STOCK", inStock[0].status)
        assertEquals(30000.0, inStock[0].totalCost, 0.01)

        // 2. Movement IN register check
        val movements = repository.getMovementsForShop("shop_1").first()
        assertEquals(1, movements.size)
        assertEquals("IN", movements[0].direction)
        assertEquals("Purchase", movements[0].reason)
        assertEquals("869123456789012", movements[0].imei)

        // 3. Cash & Bank Transaction check
        val cashBankTxs = repository.getCashBankTransactions("shop_1").first()
        assertEquals(2, cashBankTxs.size)
        val cashTx = cashBankTxs.find { it.type == "CASH_OUT" }
        val bankTx = cashBankTxs.find { it.type == "BANK_OUT" }
        assertEquals(20000.0, cashTx?.amount ?: 0.0, 0.01)
        assertEquals(10000.0, bankTx?.amount ?: 0.0, 0.01)

        // 4. Daily Entry check
        val dailyEntries = repository.getDailyEntries("shop_1").first()
        assertEquals(1, dailyEntries.size)
        assertEquals("Purchase", dailyEntries[0].entryType)
        assertEquals(30000.0, dailyEntries[0].amount, 0.01)

        // 5. Audit Log check
        val auditLogs = repository.auditDao.getLogsForShop("shop_1").first()
        assertEquals(1, auditLogs.size)
        assertEquals("CREATE", auditLogs[0].action)

        // Now test single entry sale
        repository.recordSale(
            mobile = mobile!!,
            customerName = "Amit Kumar",
            customerMobile = "9123456780",
            customerAddress = "Delhi",
            salePrice = 36000.0,
            cashPaid = 30000.0,
            bankPaid = 6000.0,
            dueAmount = 0.0,
            paymentRef = "GPay999",
            user = testUser
        )

        // Stock now 0
        val remainingStock = repository.getCurrentStock("shop_1").first()
        assertEquals(0, remainingStock.size)

        // Movement OUT check
        val updatedMovements = repository.getMovementsForShop("shop_1").first()
        val outMov = updatedMovements.find { it.direction == "OUT" }
        assertEquals("Sale", outMov?.reason)
        assertEquals(36000.0, outMov?.value ?: 0.0, 0.01)

        // Sale Record with Profit check
        val sales = repository.getSales("shop_1").first()
        assertEquals(1, sales.size)
        assertEquals(6000.0, sales[0].profitOrLoss, 0.01) // 36000 - 30000 = +6000 profit
    }
}
